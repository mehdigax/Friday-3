package com.friday.assistant

import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.URL
import java.net.UnknownHostException

class AiResult(val text: String?, val error: String?)

/** Minimal client for OpenAI-compatible chat APIs (GapGPT uses this format). Call it from a background thread. */
object AiClient {
    const val DEFAULT_URL = "https://api.gapgpt.app/v1"
    const val DEFAULT_MODEL = "gpt-4o"

    fun chat(
        baseUrl: String,
        apiKey: String,
        model: String,
        messages: List<Pair<String, String>>
    ): AiResult {
        var conn: HttpURLConnection? = null
        return try {
            val url = URL(baseUrl.trim().trimEnd('/') + "/chat/completions")
            val c = url.openConnection() as HttpURLConnection
            conn = c
            c.requestMethod = "POST"
            c.connectTimeout = 15000
            c.readTimeout = 45000
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            c.setRequestProperty("Accept", "application/json")
            c.setRequestProperty("Authorization", "Bearer " + apiKey.trim())

            val arr = JSONArray()
            for ((role, content) in messages) {
                val m = JSONObject()
                m.put("role", role)
                m.put("content", content)
                arr.put(m)
            }
            val body = JSONObject()
            body.put("model", model.trim())
            body.put("messages", arr)
            body.put("temperature", 0.6)
            body.put("max_tokens", 300)

            c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val text = if (stream == null) {
                ""
            } else {
                BufferedReader(InputStreamReader(stream, Charsets.UTF_8)).use { it.readText() }
            }
            if (code in 200..299) {
                parseSuccess(text)
            } else {
                AiResult(null, friendly(code) + extractError(text))
            }
        } catch (e: UnknownHostException) {
            AiResult(null, "به اینترنت یا آدرس سرویس وصل نشدم.")
        } catch (e: SocketTimeoutException) {
            AiResult(null, "سرویس دیر جواب داد. دوباره امتحان کن.")
        } catch (e: Exception) {
            AiResult(null, "خطا در ارتباط: " + (e.message ?: e.javaClass.simpleName))
        } finally {
            conn?.disconnect()
        }
    }

    private fun parseSuccess(body: String): AiResult =
        try {
            val content = JSONObject(body)
                .getJSONArray("choices")
                .getJSONObject(0)
                .getJSONObject("message")
                .optString("content", "")
            if (content.isBlank()) {
                AiResult(null, "پاسخ خالی بود.")
            } else {
                AiResult(content.trim(), null)
            }
        } catch (e: Exception) {
            AiResult(null, "پاسخ سرویس قابل فهم نبود: " + body.take(150))
        }

    private fun friendly(code: Int): String = when (code) {
        401, 403 -> "(کد $code) کلید API درست نیست یا اجازه‌ی دسترسی نداره. "
        402 -> "(کد $code) اعتبار حساب کافی نیست. "
        404 -> "(کد $code) آدرس سرویس یا نام مدل درست نیست. "
        429 -> "(کد $code) درخواست‌ها زیاد بود؛ کمی صبر کن. "
        in 500..599 -> "(کد $code) سرور سرویس‌دهنده مشکل داره. "
        else -> "(کد $code) "
    }

    private fun extractError(body: String): String {
        try {
            val j = JSONObject(body)
            val err = j.opt("error")
            if (err is JSONObject) {
                val m = err.optString("message", "")
                if (m.isNotEmpty()) return m.take(200)
            } else if (err is String && err.isNotEmpty()) {
                return err.take(200)
            }
            val msg = j.optString("message", "")
            if (msg.isNotEmpty()) return msg.take(200)
        } catch (e: Exception) {
            // not JSON: fall through
        }
        return body.take(200)
    }
}
