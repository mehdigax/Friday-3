package com.friday.assistant

import android.content.Context
import android.view.View
import android.widget.ScrollView

/** A ScrollView that never grows taller than [maxHeightPx] (so long answers scroll inside the card). */
class BoundedScrollView(context: Context, private val maxHeightPx: Int) : ScrollView(context) {
    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val capped = View.MeasureSpec.makeMeasureSpec(maxHeightPx, View.MeasureSpec.AT_MOST)
        super.onMeasure(widthMeasureSpec, capped)
    }
}
