package com.friday.assistant

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.KeyguardManager
import android.app.DownloadManager
import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.AudioAttributes
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Environment
import android.os.Looper
import android.os.PowerManager
import android.provider.AlarmClock
import android.provider.CalendarContract
import android.provider.ContactsContract.CommonDataKinds.Phone
import android.provider.MediaStore
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.text.InputType
import android.view.Gravity
import android.view.WindowManager
import android.view.HapticFeedbackConstants
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.CheckBox
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

data class AppInfo(val label: String, val pkg: String, val nLabel: String)
data class ContactInfo(val name: String, val number: String, val nName: String)

/** Normalizes Persian/Arabic variants, removes spaces, ZWNJ and punctuation. */
private fun norm(s: String): String =
    s.lowercase(Locale.ROOT)
        .replace('\u064A', '\u06CC') // ي -> ی
        .replace('\u0649', '\u06CC') // ى -> ی
        .replace('\u0643', '\u06A9') // ك -> ک
        .replace('\u0622', '\u0627') // آ -> ا
        .replace("\u200c", "")
        .replace(Regex("[^\\p{L}\\p{N}]"), "")

/** Canonicalizes common spoken variants that speech engines often return for Persian commands. */
private fun canonicalCommandToken(token: String): String = when (norm(token)) {
    "اهنگ", "آهنگ" -> "اهنگ"
    "ولوم", "والیوم", "ولم" -> "ولوم"
    "بلندترش", "زیادترش" -> "زیادتر"
    "کمترش", "ارومتر" -> "کمتر"
    "ببندید", "ببندش", "ببند" -> "ببند"
    "یادداشتها", "یادداشت" -> "یادداشت"
    "دانلودش", "دانلودکن", "دانلودکنش" -> "دانلود"
    "پخشش", "پخشکن", "پخشکنش" -> "پخش"
    "ادامهبده", "ادامش" -> "ادامه"
    else -> norm(token)
}

private fun String.faDigits(): String =
    map { if (it in '0'..'9') '\u06F0' + (it - '0') else it }.joinToString("")

/** Keeps only digits and a leading +, converting Persian/Arabic digits to Latin. */
private fun cleanNumber(s: String): String =
    s.filter { it.isDigit() || it == '+' }
        .map { if (it == '+') "+" else it.digitToInt().toString() }
        .joinToString("")

private val faOnes = listOf(
    "صفر", "یک", "دو", "سه", "چهار", "پنج", "شش", "هفت", "هشت", "نه", "ده",
    "یازده", "دوازده", "سیزده", "چهارده", "پانزده", "شانزده", "هفده", "هجده", "نوزده"
)
private val faTens = listOf(
    "", "", "بیست", "سی", "چهل", "پنجاه", "شصت", "هفتاد", "هشتاد", "نود"
)
private val faHundreds = listOf(
    "", "صد", "دویست", "سیصد", "چهارصد", "پانصد", "ششصد", "هفتصد", "هشتصد", "نهصد"
)

/** 1405 -> "هزار و چهارصد و پنج" (so robotic voices don't have to guess how to read digits). */
private fun faWords(n: Int): String {
    if (n == 0) return faOnes[0]
    val parts = ArrayList<String>()
    var x = n
    val thousands = x / 1000
    x %= 1000
    if (thousands > 0) {
        parts.add(if (thousands == 1) "هزار" else faWords(thousands) + " هزار")
    }
    val h = x / 100
    x %= 100
    if (h > 0) parts.add(faHundreds[h])
    if (x > 0) {
        if (x < 20) {
            parts.add(faOnes[x])
        } else {
            val t = x / 10
            val o = x % 10
            parts.add(if (o == 0) faTens[t] else faTens[t] + " و " + faOnes[o])
        }
    }
    return parts.joinToString(" و ")
}

/** Replaces digits with Persian words for speech: short numbers as a number, long ones digit by digit. */
private fun spokenFa(s: String): String =
    Regex("[0-9\\u06F0-\\u06F9]+").replace(s) { m ->
        val digits = m.value.map { it.digitToInt() }
        if (digits.size <= 4) {
            faWords(digits.joinToString("").toInt())
        } else {
            digits.joinToString(" ") { faOnes[it] }
        }
    }

private val smsWords = setOf("پیامک", "پیام", "sms", "message", "text")
private val sendVerbs = setOf(
    "بفرست", "بفرستید", "بفرستم", "بده", "بنویس", "بزن", "send", "write"
)
private val smsStopWords = setOf(
    "به", "برای", "با", "یه", "یک", "پیامک", "پیام", "sms", "message", "text",
    "لطفا", "فرایدی", "friday", "هی", "to", "a", "the", "من", "که"
)

private val faNumberWords = mapOf(
    "یک" to 1, "دو" to 2, "سه" to 3, "چهار" to 4, "پنج" to 5, "شش" to 6, "هفت" to 7,
    "هشت" to 8, "نه" to 9, "ده" to 10, "یازده" to 11, "دوازده" to 12, "سیزده" to 13,
    "چهارده" to 14, "پانزده" to 15, "شانزده" to 16, "هفده" to 17, "هجده" to 18,
    "نوزده" to 19, "بیست" to 20, "سی" to 30, "چهل" to 40, "پنجاه" to 50, "شصت" to 60,
    "هفتاد" to 70, "هشتاد" to 80, "نود" to 90, "صد" to 100, "یکصد" to 100
)

/** Converts Persian/Arabic digits to Latin ones. */
private fun toAscii(s: String): String =
    s.map { if (it.isDigit()) it.digitToInt().toString() else it.toString() }.joinToString("")

/** "7" -> 7, "هفت" -> 7 */
private fun numberToken(t: String?): Int? {
    if (t == null) return null
    val n = norm(t)
    val asInt = n.toIntOrNull()
    if (asInt != null) return asInt
    return faNumberWords[n]
}

private fun finishClock(h0: Int, m: Int, ascii: String): Pair<Int, Int>? {
    val s = norm(ascii)
    var h = h0
    val evening = s.contains("عصر") || s.contains("شب") || s.contains("بعدازظهر")
    if (evening && h in 1..11) {
        h += 12
    } else if (s.contains("ظهر") && h in 1..4) {
        h += 12
    }
    if (s.contains("شب") && h0 == 12) {
        h = 0
    }
    if (h > 23 || m > 59) return null
    return Pair(h, m)
}

/** Understands "ساعت ۷", "ساعت هفت و نیم", "۶:۴۵", "ساعت ۸ شب" ... */
private fun parseClock(raw: String): Pair<Int, Int>? {
    val ascii = toAscii(raw)
    val colon = Regex("(\\d{1,2})\\s*[:.\\u066B]\\s*(\\d{2})").find(ascii)
    if (colon != null) {
        return finishClock(colon.groupValues[1].toInt(), colon.groupValues[2].toInt(), ascii)
    }
    val tokens = ascii.split(Regex("\\s+")).filter { it.isNotEmpty() }
    val i = tokens.indexOfFirst { norm(it) == "ساعت" }
    if (i < 0) return null
    val h = numberToken(tokens.getOrNull(i + 1)) ?: return null
    val rest = tokens.drop(i + 2).map { norm(it) }
    var m = 0
    if (rest.firstOrNull() == "و") {
        val w = rest.getOrNull(1)
        m = when {
            w == "نیم" -> 30
            w == "ربع" -> 15
            else -> numberToken(w) ?: 0
        }
    }
    return finishClock(h, m, ascii)
}

/** Understands "۵ دقیقه", "نیم ساعت", "۱ ساعت و ۳۰ دقیقه", "۱۰ ثانیه" ... */
private fun parseDurationSeconds(raw: String): Int {
    val tokens = toAscii(raw).split(Regex("\\s+")).map { norm(it) }.filter { it.isNotEmpty() }
    var total = 0
    for (i in tokens.indices) {
        val unit = tokens.getOrNull(i + 1) ?: continue
        val mult = when (unit) {
            "ساعت", "hour", "hours" -> 3600
            "دقیقه", "minute", "minutes", "min" -> 60
            "ثانیه", "second", "seconds", "sec" -> 1
            else -> 0
        }
        if (mult == 0) continue
        val t = tokens[i]
        if (t == "نیم") {
            total += mult / 2
        } else if (t == "ربع") {
            total += mult / 4
        } else {
            val n = numberToken(t)
            if (n != null) total += n * mult
        }
    }
    if (total == 0 && tokens.contains("ربع")) total = 900
    return total
}

private fun describeDuration(total: Int): String {
    val h = total / 3600
    val m = (total % 3600) / 60
    val s = total % 60
    val parts = ArrayList<String>()
    if (h > 0) parts.add("$h ساعت")
    if (m > 0) parts.add("$m دقیقه")
    if (s > 0) parts.add("$s ثانیه")
    return parts.joinToString(" و ")
}

/** Gregorian -> Jalali (Persian) date. Returns (year, month, day). */
private fun gregorianToJalali(gy0: Int, gm: Int, gd: Int): Triple<Int, Int, Int> {
    val gdm = intArrayOf(0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334)
    var jy: Int
    var gy = gy0
    if (gy > 1600) {
        jy = 979
        gy -= 1600
    } else {
        jy = 0
        gy -= 621
    }
    val gy2 = if (gm > 2) gy + 1 else gy
    var days = (365 * gy) + ((gy2 + 3) / 4) - ((gy2 + 99) / 100) + ((gy2 + 399) / 400) -
        80 + gd + gdm[gm - 1]
    jy += 33 * (days / 12053)
    days %= 12053
    jy += 4 * (days / 1461)
    days %= 1461
    if (days > 365) {
        jy += (days - 1) / 365
        days = (days - 1) % 365
    }
    val jm: Int
    val jd: Int
    if (days < 186) {
        jm = 1 + days / 31
        jd = 1 + days % 31
    } else {
        jm = 7 + (days - 186) / 30
        jd = 1 + (days - 186) % 30
    }
    return Triple(jy, jm, jd)
}

class MainActivity : Activity() {

    private lateinit var orb: OrbView
    private lateinit var statusView: TextView
    private lateinit var heardView: TextView
    private lateinit var cancelButton: TextView
    private lateinit var langPill: TextView
    private lateinit var inputView: EditText
    private lateinit var wakePill: TextView

    private val handler = Handler(Looper.getMainLooper())
    private var pendingCall: Runnable? = null

    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var langTag = "fa-IR"
    private var autoListen = false
    private var torchOn = false
    private var localPlayer: MediaPlayer? = null
    private var pendingLocalMusicQuery: String? = null

    // --- AI brain (GapGPT / any OpenAI-compatible service)
    private var aiCounter = 0
    private var lastRaw = ""
    private var alts: List<String> = emptyList() // the recognizer's guesses, best first
    private var altIndex = 0
    private var fromWake = false
    private val lockCloseRunnable = Runnable {
        if (fromWake && isLocked()) finishAndRemoveTask()
    }
    private val aiHistory = ArrayList<Pair<String, String>>()
    private val aiPrefs by lazy { getSharedPreferences("friday_ai", Context.MODE_PRIVATE) }

    companion object {
        /** Set by the home-screen widget: start listening as soon as the app opens. */
        const val EXTRA_LISTEN = "friday_listen"

        /** Set by the wake-word service: run this sentence as a command right away. */
        const val EXTRA_COMMAND = "friday_command"

        /** Set when the wake-word service opened Friday (so it can close itself on the lock screen). */
        const val EXTRA_FROM_WAKE = "friday_from_wake"

        /** True while Friday's screen is in front (used by the wake-word fallback). */
        @Volatile
        var visible = false
    }

    private val MP = ViewGroup.LayoutParams.MATCH_PARENT
    private val WC = ViewGroup.LayoutParams.WRAP_CONTENT

    private val faWeekdays = listOf(
        "یکشنبه", "دوشنبه", "سه‌شنبه", "چهارشنبه", "پنجشنبه", "جمعه", "شنبه"
    )
    private val faMonths = listOf(
        "فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور",
        "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند"
    )

    private val openWords = setOf(
        "باز", "بازکن", "بازکنید", "بازکردن", "بازش", "اجرا", "اجراکن", "open", "launch", "start"
    )
    private val stopWords = openWords + setOf(
        "کن", "لطفا", "برنامه", "برنامهی", "اپلیکیشن", "نرمافزار", "رو", "را",
        "به", "برو", "فرایدی", "friday", "هی", "the", "app"
    )

    private val callWords = setOf("زنگ", "تماس", "call", "dial")
    private val lockedBlock: Set<String> = openWords + callWords + smsWords + setOf(
        "مسیریابی", "مسیر", "برو", "جستجو", "سرچ", "search", "navigate", "directions",
        "یادمبنداز", "یادم", "رویداد", "وایفای", "wifi", "بلوتوث", "bluetooth", "تنظیمات", "settings"
    )
    private val callStopWords = callWords + setOf(
        "بزن", "بزنید", "بگیر", "بگیرید", "به", "با", "رو", "را", "کن", "لطفا",
        "فرایدی", "friday", "هی", "to", "please", "شماره", "برای", "من"
    )

    // Persian spoken name -> keywords to look for in app label / package name
    private val aliases: List<Pair<String, List<String>>> = listOf(
        "واتساپ" to listOf("whatsapp"),
        "واتسپ" to listOf("whatsapp"),
        "واتساب" to listOf("whatsapp"),
        "واتس" to listOf("whatsapp"),
        "تلگرام" to listOf("telegram"),
        "اینستاگرام" to listOf("instagram"),
        "اینستا" to listOf("instagram"),
        "یوتیوب" to listOf("youtube"),
        "کروم" to listOf("chrome"),
        "گوگلمپ" to listOf("com.google.android.apps.maps"),
        "نقشه" to listOf("com.google.android.apps.maps", "maps"),
        "گوگل" to listOf("com.google.android.googlequicksearchbox"),
        "دوربین" to listOf("camera"),
        "تنظیمات" to listOf("com.android.settings", "settings"),
        "گالری" to listOf("gallery", "photos"),
        "ماشینحساب" to listOf("calculator"),
        "ساعت" to listOf("clock"),
        "تقویم" to listOf("calendar"),
        "مخاطبین" to listOf("contacts"),
        "تماس" to listOf("dialer", "phone"),
        "پیامک" to listOf("messag", "mms"),
        "ایتا" to listOf("eitaa"),
        "روبیکا" to listOf("rubika"),
        "اسنپ" to listOf("snapp"),
        "دیجیکالا" to listOf("digikala"),
        "بازار" to listOf("bazaar"),
        "مایکت" to listOf("myket"),
        "موزیک" to listOf("music"),
        "فایل" to listOf("files"),
        "پلیاستور" to listOf("com.android.vending")
    ).map { norm(it.first) to it.second }
        .sortedByDescending { it.first.length }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT < 27) {
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                    WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
            )
        }
        buildUi()
        tts = TextToSpeech(this) { status -> ttsReady = (status == TextToSpeech.SUCCESS) }
        requestAllPerms()
        handleLaunchIntent(intent)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        if (intent != null) {
            setIntent(intent)
            handleLaunchIntent(intent)
        }
    }

    /** When opened from the widget, start listening right away (no extra tap needed). */
    private fun handleLaunchIntent(i: Intent?) {
        if (i == null) return
        if (i.getBooleanExtra(EXTRA_FROM_WAKE, false)) {
            i.removeExtra(EXTRA_FROM_WAKE)
            fromWake = true
            scheduleLockClose()
        }
        val cmd = i.getStringExtra(EXTRA_COMMAND)
        if (cmd != null) {
            i.removeExtra(EXTRA_COMMAND)
            handler.postDelayed({ handle(cmd) }, 1000L)
            return
        }
        if (!i.getBooleanExtra(EXTRA_LISTEN, false)) return
        i.removeExtra(EXTRA_LISTEN)
        if (hasPerm(Manifest.permission.RECORD_AUDIO)) {
            handler.postDelayed({ startListening() }, 350L)
        } else {
            autoListen = true // start once the mic permission is granted
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 6) {
            val q = pendingLocalMusicQuery
            pendingLocalMusicQuery = null
            if (q != null) {
                handler.post {
                    if (hasAudioReadPermission()) {
                        if (!playLocalMusic(q)) launchMusicSearch(q)
                    } else {
                        reply("اجازه‌ی دسترسی به آهنگ‌های گوشی داده نشد؛ دارم برنامه‌ی موسیقی رو برای جستجو باز می‌کنم.", "Audio permission denied; opening a music app.")
                        launchMusicSearch(q)
                    }
                }
            }
            return
        }
        if (!hasPerm(Manifest.permission.RECORD_AUDIO)) {
            autoListen = false
            setStatus("بدون اجازه‌ی میکروفون نمی‌تونم صدات رو بشنوم.")
        } else if (autoListen) {
            autoListen = false
            handler.postDelayed({ startListening() }, 350L)
        }
    }

    override fun onResume() {
        super.onResume()
        visible = true
        updateWakePill()
        maybeResumeWake()
    }

    override fun onPause() {
        visible = false
        super.onPause()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        recognizer?.destroy()
        tts?.shutdown()
        try { localPlayer?.release() } catch (_: Exception) { }
        localPlayer = null
        super.onDestroy()
    }

    // ---------------------------------------------------------------- Permissions

    private fun hasPerm(p: String): Boolean =
        checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    private fun requestAllPerms() {
        val need = arrayOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.CALL_PHONE
        ).filter { !hasPerm(it) }
        if (need.isNotEmpty()) {
            requestPermissions(need.toTypedArray(), 1)
        }
    }

    // ---------------------------------------------------------------- UI

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun shape(
        fill: Int,
        radiusDp: Int,
        strokeColor: Int = 0,
        strokeDp: Int = 0
    ): GradientDrawable {
        val g = GradientDrawable()
        g.shape = GradientDrawable.RECTANGLE
        g.cornerRadius = dp(radiusDp).toFloat()
        g.setColor(fill)
        if (strokeDp > 0) {
            g.setStroke(dp(strokeDp), strokeColor)
        }
        return g
    }

    private fun buildUi() {
        window.statusBarColor = Color.parseColor("#070B1A")
        window.navigationBarColor = Color.parseColor("#1A1040")

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.background = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(
                Color.parseColor("#070B1A"),
                Color.parseColor("#0E1530"),
                Color.parseColor("#1A1040")
            )
        )
        root.setPadding(dp(20), dp(12), dp(20), dp(20))

        // ---- top bar: title + language pill
        val topBar = LinearLayout(this)
        topBar.orientation = LinearLayout.HORIZONTAL
        topBar.gravity = Gravity.CENTER_VERTICAL

        val titleBox = LinearLayout(this)
        titleBox.orientation = LinearLayout.VERTICAL

        val title = TextView(this)
        title.text = "FRIDAY"
        title.textSize = 24f
        title.letterSpacing = 0.3f
        title.typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
        title.setTextColor(Color.parseColor("#E8F6FF"))

        val subtitle = TextView(this)
        subtitle.text = "VOICE ASSISTANT"
        subtitle.textSize = 10.5f
        subtitle.letterSpacing = 0.25f
        subtitle.setTextColor(Color.parseColor("#29D8FF"))

        titleBox.addView(title)
        titleBox.addView(subtitle)

        langPill = TextView(this)
        langPill.text = "🌐 FA"
        langPill.textSize = 13f
        langPill.setTextColor(Color.parseColor("#C9D1E7"))
        langPill.setPadding(dp(14), dp(8), dp(14), dp(8))
        langPill.background = shape(
            Color.parseColor("#14FFFFFF"), 20, Color.parseColor("#33FFFFFF"), 1
        )
        langPill.setOnClickListener { toggleLang() }

        wakePill = TextView(this)
        wakePill.textSize = 13f
        wakePill.setPadding(dp(12), dp(8), dp(12), dp(8))
        wakePill.setOnClickListener { toggleWake() }
        updateWakePill()

        topBar.addView(titleBox, LinearLayout.LayoutParams(0, WC, 1f))
        val wakeParams = LinearLayout.LayoutParams(WC, WC)
        wakeParams.rightMargin = dp(8)
        topBar.addView(wakePill, wakeParams)
        topBar.addView(langPill)

        val gearPill = TextView(this)
        gearPill.text = "⚙️"
        gearPill.textSize = 14f
        gearPill.setPadding(dp(12), dp(8), dp(12), dp(8))
        gearPill.background = shape(
            Color.parseColor("#14FFFFFF"), 20, Color.parseColor("#33FFFFFF"), 1
        )
        gearPill.setOnClickListener { runWhenUnlocked { showSettingsMenu() } }
        val gearParams = LinearLayout.LayoutParams(WC, WC)
        gearParams.leftMargin = dp(8)
        topBar.addView(gearPill, gearParams)

        // ---- orb (tap to talk)
        val orbBox = FrameLayout(this)
        orb = OrbView(this)
        orb.setOnClickListener { onOrbClick() }
        orbBox.addView(orb, FrameLayout.LayoutParams(MP, MP, Gravity.CENTER))

        // ---- cancel-call pill (only visible while a call is pending)
        cancelButton = TextView(this)
        cancelButton.text = "✋  لغو تماس"
        cancelButton.textSize = 17f
        cancelButton.setTextColor(Color.WHITE)
        cancelButton.typeface = Typeface.DEFAULT_BOLD
        cancelButton.gravity = Gravity.CENTER
        cancelButton.setPadding(dp(20), dp(12), dp(20), dp(12))
        cancelButton.background = shape(Color.parseColor("#E63950"), 28)
        cancelButton.visibility = View.GONE
        cancelButton.setOnClickListener {
            cancelPending()
            setStatus("تماس لغو شد.")
        }

        // ---- glass card with status + what was heard
        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.gravity = Gravity.CENTER
        card.minimumHeight = dp(130)
        card.setPadding(dp(20), dp(18), dp(20), dp(18))
        card.background = shape(
            Color.parseColor("#14FFFFFF"), 26, Color.parseColor("#2629D8FF"), 1
        )

        statusView = TextView(this)
        statusView.text = "سلام! من فرایدی‌م 👋\nروی دایره بزن و حرف بزن،\nیا پایین تایپ کن."
        statusView.textSize = 19f
        statusView.setLineSpacing(0f, 1.15f)
        statusView.setTextColor(Color.parseColor("#F2F7FF"))
        statusView.gravity = Gravity.CENTER

        heardView = TextView(this)
        heardView.textSize = 14f
        heardView.setTextColor(Color.parseColor("#7F8BB0"))
        heardView.gravity = Gravity.CENTER
        heardView.setPadding(0, dp(8), 0, 0)
        heardView.setOnClickListener { tryNextGuess() }
        heardView.visibility = View.GONE

        val statusScroll = BoundedScrollView(this, dp(260))
        statusScroll.isVerticalScrollBarEnabled = false
        statusScroll.addView(statusView)
        card.addView(statusScroll, LinearLayout.LayoutParams(MP, WC))
        card.addView(heardView, LinearLayout.LayoutParams(MP, WC))

        // ---- typed command bar
        val inputRow = LinearLayout(this)
        inputRow.orientation = LinearLayout.HORIZONTAL
        inputRow.gravity = Gravity.CENTER_VERTICAL

        inputView = EditText(this)
        inputView.background = shape(
            Color.parseColor("#14FFFFFF"), 26, Color.parseColor("#33FFFFFF"), 1
        )
        inputView.setPadding(dp(18), dp(12), dp(18), dp(12))
        inputView.hint = "یا دستورت رو تایپ کن..."
        inputView.setHintTextColor(Color.parseColor("#5E6A8F"))
        inputView.setTextColor(Color.parseColor("#F2F7FF"))
        inputView.textSize = 16f
        inputView.inputType = InputType.TYPE_CLASS_TEXT
        inputView.setSingleLine(true)
        inputView.imeOptions = EditorInfo.IME_ACTION_SEND
        inputView.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEND) {
                submitTyped()
                true
            } else {
                false
            }
        }

        val sendBtn = ImageView(this)
        sendBtn.setImageResource(R.drawable.ic_send)
        sendBtn.setPadding(dp(12), dp(12), dp(12), dp(12))
        val sendBg = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(Color.parseColor("#29D8FF"), Color.parseColor("#3A6BFF"))
        )
        sendBg.shape = GradientDrawable.OVAL
        sendBtn.background = sendBg
        sendBtn.setOnClickListener { submitTyped() }

        inputRow.addView(inputView, LinearLayout.LayoutParams(0, WC, 1f))
        val sendParams = LinearLayout.LayoutParams(dp(48), dp(48))
        sendParams.leftMargin = dp(10)
        inputRow.addView(sendBtn, sendParams)

        // ---- example hint
        val hint = TextView(this)
        hint.text = "«واتساپ رو باز کن»  •  «ساعت چنده؟»  •  «به علی زنگ بزن»\n«چراغ قوه روشن کن»  •  «آلارم ساعت ۷»  •  «تایمر ۵ دقیقه»"
        hint.textSize = 12.5f
        hint.setTextColor(Color.parseColor("#5E6A8F"))
        hint.gravity = Gravity.CENTER
        hint.setPadding(0, dp(14), 0, 0)

        root.addView(topBar, LinearLayout.LayoutParams(MP, WC))
        root.addView(orbBox, LinearLayout.LayoutParams(MP, 0, 1f))
        val cancelParams = LinearLayout.LayoutParams(MP, WC)
        cancelParams.bottomMargin = dp(12)
        root.addView(cancelButton, cancelParams)
        root.addView(card, LinearLayout.LayoutParams(MP, WC))
        val inputParams = LinearLayout.LayoutParams(MP, WC)
        inputParams.topMargin = dp(12)
        root.addView(inputRow, inputParams)
        root.addView(hint, LinearLayout.LayoutParams(MP, WC))

        setContentView(root)
    }

    private fun setStatus(text: String) {
        statusView.alpha = 0f
        statusView.text = text
        statusView.animate().alpha(1f).setDuration(220).start()
    }

    private fun setHeard(text: String) {
        if (text.isEmpty()) {
            heardView.visibility = View.GONE
        } else {
            heardView.text = text
            heardView.visibility = View.VISIBLE
        }
    }

    private fun onOrbClick() {
        hideKeyboard()
        orb.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
        orb.animate().scaleX(0.93f).scaleY(0.93f).setDuration(90).withEndAction {
            orb.animate().scaleX(1f).scaleY(1f).setDuration(140).start()
        }.start()
        startListening()
    }

    /** Runs a command that was typed instead of spoken. */
    private fun submitTyped() {
        val text = inputView.text.toString().trim()
        if (text.isEmpty()) return
        inputView.setText("")
        hideKeyboard()
        recognizer?.cancel()
        orb.listening = false
        tts?.stop()
        handle(text)
    }

    private fun hideKeyboard() {
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(inputView.windowToken, 0)
        inputView.clearFocus()
    }

    private fun toggleLang() {
        if (langTag == "fa-IR") {
            langTag = "en-US"
            langPill.text = "🌐 EN"
        } else {
            langTag = "fa-IR"
            langPill.text = "🌐 FA"
        }
    }

    // ---------------------------------------------------------------- Listening

    private fun startListening() {
        if (WakeService.running) {
            val pause = Intent(this, WakeService::class.java)
            pause.action = WakeService.ACTION_PAUSE
            startService(pause)
            handler.postDelayed({ beginListening() }, 500L)
        } else {
            beginListening()
        }
    }

    private fun beginListening() {
        if (!hasPerm(Manifest.permission.RECORD_AUDIO)) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            setStatus("سرویس تشخیص گفتار گوگل روی این گوشی پیدا نشد.")
            return
        }
        recognizer?.destroy()
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                // only now is the microphone really open: show it and buzz so you know when to talk
                orb.listening = true
                orb.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
                setStatus("بگو...")
            }

            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}

            override fun onEndOfSpeech() {
                setStatus("دارم می‌فهمم...")
            }

            override fun onPartialResults(partialResults: Bundle?) {
                val p = partialResults
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull()
                if (!p.isNullOrBlank()) {
                    heardView.text = "«$p»"
                    heardView.visibility = View.VISIBLE
                }
            }

            override fun onEvent(eventType: Int, params: Bundle?) {}

            override fun onError(error: Int) {
                orb.listening = false
                val msg = when (error) {
                    1, 2, 4, 11 -> "اینترنت یا سرویس گفتار گوگل در دسترس نیست. اینترنت رو چک کن."
                    3 -> "میکروفون مشکل داره یا برنامه‌ی دیگه‌ای ازش استفاده می‌کنه."
                    6 -> "صدایی نشنیدم. بعد از لرزش گوشی (حلقه‌ی صورتی) حرف بزن."
                    7 -> "متوجه نشدم چی گفتی. نزدیک‌تر و واضح‌تر بگو، یا تایپ کن."
                    8 -> "سرویس گفتار مشغوله. چند ثانیه بعد دوباره امتحان کن."
                    9 -> "اجازه‌ی میکروفون داده نشده."
                    12, 13 -> "زبان فارسی برای تشخیص گفتار روی این گوشی فعال یا نصب نیست. توی تنظیمات برنامه‌ی Google اضافه‌ش کن."
                    else -> "متوجه نشدم، دوباره روی دایره بزن. (کد $error)"
                }
                setStatus(msg)
            }

            override fun onResults(results: Bundle?) {
                orb.listening = false
                val list = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                if (list.isNullOrEmpty()) {
                    setStatus("چیزی نشنیدم.")
                    return
                }
                val ordered = rankCandidates(list)
                if (ordered.isEmpty()) {
                    setStatus("چیزی نشنیدم.")
                    return
                }
                alts = ordered
                altIndex = 0
                handle(ordered[0])
            }
        })

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        intent.putExtra(
            RecognizerIntent.EXTRA_LANGUAGE_MODEL,
            RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
        )
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, langTag)
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, langTag)
        intent.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
        intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
        intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        // don't cut me off too early
        intent.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1800L)
        intent.putExtra(
            RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1500L
        )
        intent.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 800L)
        // hint words (Android 13+): my name, custom names, app names, contacts
        val hints = recognitionHints()
        if (hints.isNotEmpty()) {
            intent.putStringArrayListExtra(RecognizerIntent.EXTRA_BIASING_STRINGS, hints)
        }

        tts?.stop() // never listen to my own voice
        orb.listening = false
        setHeard("")
        setStatus("یه لحظه...")
        r.startListening(intent)
    }

    // ---------------------------------------------------------------- Better hearing

    private fun aliasNames(): List<String> =
        (settingsPrefs.getString("aliases", "") ?: "").split("\n")
            .map { it.split(Regex("\\s*(=|->|→|:)\\s*"), limit = 2)[0].trim() }
            .filter { it.isNotEmpty() }

    /** Words the recognizer should expect (used on Android 13+). */
    private fun recognitionHints(): ArrayList<String> {
        val out = LinkedHashSet<String>()
        out.add("فرایدی")
        out.addAll(aliasNames())
        try {
            for (a in loadApps().take(60)) out.add(a.label)
        } catch (e: Exception) {
            // ignore
        }
        if (hasPerm(Manifest.permission.READ_CONTACTS)) {
            try {
                for (n in loadContacts().map { it.name }.distinct().take(60)) out.add(n)
            } catch (e: Exception) {
                // ignore
            }
        }
        return ArrayList(out)
    }

    /**
     * The recognizer returns several guesses. Put first the one that looks most like something
     * Friday can do: command words, app names, my custom names, contact names.
     */
    private fun rankCandidates(list: List<String>): List<String> {
        val clean = list.map { it.trim() }.filter { it.isNotEmpty() }.distinct()
        if (clean.size <= 1) return clean

        val apps = try {
            loadApps().map { it.nLabel }.filter { it.length >= 3 }
        } catch (e: Exception) {
            emptyList()
        }
        val names = if (hasPerm(Manifest.permission.READ_CONTACTS)) {
            try {
                loadContacts().map { it.nName }.filter { it.length >= 2 }.distinct()
            } catch (e: Exception) {
                emptyList()
            }
        } else {
            emptyList()
        }
        val custom = aliasNames().map { norm(it) }.filter { it.isNotEmpty() }
        val keywords = listOf(
            "ساعت", "تاریخ", "الارم", "تایمر", "چراغقوه", "وایفای", "بلوتوث", "مسیریابی",
            "جستجو", "اهنگ", "صدا", "پیامک", "یادمبنداز", "باز", "زنگ", "تماس"
        )

        val scored = clean.mapIndexed { idx, text ->
            val n = text.split(Regex("\\s+")).map { norm(it) }.filter { it.isNotEmpty() }
            val full = n.joinToString("")
            var score = 0.0
            if (n.any { it in openWords || it in callWords }) score += 3.0
            for (k in keywords) if (full.contains(k)) score += 1.0
            for (a in aliases) if (full.contains(a.first)) score += 3.0
            for (c in custom) if (full.contains(c)) score += 3.0
            for (a in apps) if (full.contains(a)) score += 3.0
            for (nm in names) if (full.contains(nm)) score += 2.0
            score -= idx * 0.1 // otherwise trust the recognizer's own order
            Pair(text, score)
        }
        return scored.sortedByDescending { it.second }.map { it.first }
    }

    private fun showHeard(raw: String) {
        val hint = if (alts.size > 1) "\n(اشتباه شنیدم؟ اینجا بزن تا حدس بعدی رو امتحان کنم)" else ""
        setHeard("«$raw»$hint")
    }

    private fun tryNextGuess() {
        if (alts.size < 2) return
        altIndex = (altIndex + 1) % alts.size
        handle(alts[altIndex])
    }

    // ---------------------------------------------------------------- Commands

    private fun handle(raw: String) {
        if (raw != alts.getOrNull(altIndex)) alts = emptyList()
        showHeard(raw)
        lastRaw = raw
        cancelPending()
        val tokens = raw.split(Regex("\\s+")).map { canonicalCommandToken(it) }.filter { it.isNotEmpty() }
        val full = tokens.joinToString("")

        // Close Friday itself; Android does not permit ordinary apps to force-stop other apps.
        if (hasAny(full, "برنامهروببند", "ببندبرنامه", "فرایدیروببند", "خروجازبرنامه", "بستنبرنامه", "فرایدیوببند", "closefriday", "exitfriday", "quitfriday") ||
            (hasAny(full, "ببند", "ببندش", "خارجشو", "خروج") && hasAny(full, "برنامه", "فرایدی", "اپ", "خودت", "خودتو", "بیرون"))) {
            reply("باشه، فرایدی رو می‌بندم.", "Closing Friday")
            handler.postDelayed({
                try {
                    if (WakeService.running) stopService(Intent(this, WakeService::class.java))
                    visible = false
                    finishAndRemoveTask()
                } catch (_: Exception) { finish() }
            }, 650L)
            return
        }

        // On a locked phone only "safe" commands run (time, flashlight, volume, music, AI answers...).
        // Anything that opens apps, calls, texts, searches... asks you to unlock first.
        if (isLocked() && tokens.any { it in lockedBlock }) {
            runWhenUnlocked { handle(raw) }
            return
        }

        // 0) flashlight / wifi / bluetooth / alarm / timer / sms
        if (handleDeviceCommands(raw, tokens, full)) return
        if (handleExtraCommands(raw, tokens, full)) return

        // 1) open an app
        val wantsOpen = tokens.any { it in openWords } || full.contains("بازکن")
        if (wantsOpen) {
            val query = tokens.filter { it !in stopWords }.joinToString("")
            openApp(query, full)
            return
        }

        // 2) call someone
        val wantsCall = tokens.any { it in callWords } ||
            full.contains("زنگبزن") || full.contains("تماسبگیر")
        if (wantsCall) {
            handleCall(raw, tokens)
            return
        }

        // 3) time / date
        val hasClock = full.contains("ساعت")
        val hasDate = full.contains("تاریخ")
        val wantTime = (hasClock && (tokens.size <= 3 || full.contains("چند") ||
            full.contains("الان") || (hasDate && tokens.size <= 6))) ||
            (tokens.size <= 4 && full.contains("time"))
        val wantDate = full.contains("چندمه") || full.contains("چهروزی") ||
            full.contains("تاریخامروز") ||
            (hasDate && (tokens.size <= 2 || (hasClock && tokens.size <= 6))) ||
            (tokens.size <= 3 && (full.contains("امروز") || full.contains("today"))) ||
            (tokens.size <= 4 && full.contains("date"))

        if (wantTime || wantDate) {
            answerTimeDate(wantTime, wantDate)
        } else {
            askAi(raw)
        }
    }

    // ---------------------------------------------------------------- Wake mode (experimental)

    private fun updateWakePill() {
        val on = WakeService.running
        wakePill.text = if (on) "👂 روشن" else "👂 خاموش"
        wakePill.setTextColor(Color.parseColor(if (on) "#29D8FF" else "#C9D1E7"))
        wakePill.background = shape(
            Color.parseColor("#14FFFFFF"), 20,
            Color.parseColor(if (on) "#8029D8FF" else "#33FFFFFF"), 1
        )
    }

    // ---------------------------------------------------------------- Lock screen & always-on

    private fun isLocked(): Boolean {
        val km = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        return km.isKeyguardLocked
    }

    /** Runs [action] now, or - if the phone is locked - after you unlock it (fingerprint / PIN). */
    private fun runWhenUnlocked(action: () -> Unit) {
        if (!isLocked() || Build.VERSION.SDK_INT < 26) {
            action()
            return
        }
        setStatus("برای ادامه، قفل گوشی رو باز کن.")
        val km = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        km.requestDismissKeyguard(this, object : KeyguardManager.KeyguardDismissCallback() {
            override fun onDismissSucceeded() {
                action()
            }

            override fun onDismissCancelled() {
                setStatus("قفل گوشی باز نشد.")
            }

            override fun onDismissError() {
                setStatus("نتونستم قفل گوشی رو باز کنم.")
            }
        })
    }

    private fun startActivityDirect(intent: Intent) {
        super.startActivity(intent)
    }

    /** Anything that leaves Friday for another app needs the phone unlocked. */
    override fun startActivity(intent: Intent?) {
        if (intent != null && Build.VERSION.SDK_INT >= 26 && isLocked() &&
            intent.component?.packageName != packageName
        ) {
            runWhenUnlocked { startActivityDirect(intent) }
            return
        }
        super.startActivity(intent)
    }

    /** When Friday was opened by the wake word over the lock screen, close it again after a while. */
    private fun scheduleLockClose() {
        handler.removeCallbacks(lockCloseRunnable)
        if (fromWake) handler.postDelayed(lockCloseRunnable, 20000L)
    }

    private fun startWakeService() {
        val serviceIntent = Intent(this, WakeService::class.java)
        serviceIntent.putExtra(WakeService.EXTRA_LANG, langTag)
        if (Build.VERSION.SDK_INT >= 26) {
            startForegroundService(serviceIntent)
        } else {
            startService(serviceIntent)
        }
    }

    /** Wake mode was on but Android stopped it (or the phone rebooted): start it again. */
    private fun maybeResumeWake() {
        if (WakeService.running) return
        if (!settingsPrefs.getBoolean("wake_on", false)) return
        if (!hasPerm(Manifest.permission.RECORD_AUDIO) || !Settings.canDrawOverlays(this)) return
        try {
            startWakeService()
        } catch (e: Exception) {
            return
        }
        handler.postDelayed({ updateWakePill() }, 600L)
    }

    private fun requestBatteryExemption() {
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        if (!pm.isIgnoringBatteryOptimizations(packageName)) {
            startSafely(
                Intent(
                    Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                    Uri.parse("package:$packageName")
                )
            )
        }
    }

    private fun toggleWake() {
        if (WakeService.running) {
            settingsPrefs.edit().putBoolean("wake_on", false).apply()
            stopService(Intent(this, WakeService::class.java))
            handler.postDelayed({ updateWakePill() }, 400L)
            setStatus("حالت بیدار شدن با «فرایدی» خاموش شد.")
            return
        }
        if (!hasPerm(Manifest.permission.RECORD_AUDIO)) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
            setStatus("اول اجازه‌ی میکروفون رو بده، بعد دوباره بزن.")
            return
        }
        if (Build.VERSION.SDK_INT >= 33 && !hasPerm(Manifest.permission.POST_NOTIFICATIONS)) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 3)
            setStatus("اجازه‌ی نوتیفیکیشن رو بده، بعد دوباره بزن.")
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            setStatus(
                "برای اینکه فرایدی بعد از شنیدن اسمش خودش باز بشه، اجازه‌ی «نمایش روی برنامه‌های دیگر» رو روشن کن، بعد برگرد و دوباره بزن."
            )
            startSafely(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
            return
        }
        val serviceIntent = Intent(this, WakeService::class.java)
        serviceIntent.putExtra(WakeService.EXTRA_LANG, langTag)
        if (Build.VERSION.SDK_INT >= 26) {
            startForegroundService(serviceIntent)
        } else {
            startService(serviceIntent)
        }
        handler.postDelayed({ updateWakePill() }, 600L)
        settingsPrefs.edit().putBoolean("wake_on", true).apply()
        requestBatteryExemption()
        setStatus("حالت بیدار شدن روشن شد (آزمایشی). بگو «فرایدی» یا «بیدار شو» و بعدش دستورت رو.")
    }

    // ---------------------------------------------------------------- Device commands

    private fun startSafely(intent: Intent): Boolean =
        try {
            startActivity(intent)
            true
        } catch (e: Exception) {
            false
        }

    private fun setTorch(on: Boolean): Boolean {
        try {
            val cm = getSystemService(Context.CAMERA_SERVICE) as CameraManager
            var flashId: String? = null
            for (id in cm.cameraIdList) {
                val c = cm.getCameraCharacteristics(id)
                val hasFlash = c.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
                val back = c.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
                if (hasFlash && back) {
                    flashId = id
                    break
                }
            }
            if (flashId == null) return false
            cm.setTorchMode(flashId, on)
            torchOn = on
            return true
        } catch (e: Exception) {
            return false
        }
    }

    /** Returns true when the sentence was one of these commands. */
    private fun handleDeviceCommands(raw: String, tokens: List<String>, full: String): Boolean {
        // flashlight
        if (full.contains("چراغقوه") || full.contains("فلش") ||
            full.contains("flashlight") || full.contains("torch")
        ) {
            val off = full.contains("خاموش") || tokens.contains("off")
            val on = full.contains("روشن") || tokens.contains("on")
            val target = if (off) false else if (on) true else !torchOn
            if (setTorch(target)) {
                reply(
                    if (target) "چراغ‌قوه روشن شد" else "چراغ‌قوه خاموش شد",
                    if (target) "Flashlight on" else "Flashlight off"
                )
            } else {
                if (!hasPerm(Manifest.permission.CAMERA)) {
                    requestPermissions(arrayOf(Manifest.permission.CAMERA), 5)
                    reply(
                        "اگه چراغ قوه روشن نشد، اجازه‌ی دوربین رو بده و دوباره بگو.",
                        "Please allow camera access for the flashlight, then try again."
                    )
                } else {
                    reply("چراغ قوه روی این گوشی در دسترس نیست.", "The flashlight isn't available.")
                }
            }
            return true
        }

        // wifi (Android doesn't let apps switch it directly -> open the panel)
        if (full.contains("وایفای") || full.contains("wifi")) {
            val i = if (Build.VERSION.SDK_INT >= 30) {
                Intent(Settings.Panel.ACTION_WIFI)
            } else {
                Intent(Settings.ACTION_WIFI_SETTINGS)
            }
            reply(
                "پنل وای‌فای رو باز می‌کنم. اندروید اجازه نمی‌ده برنامه‌ها مستقیم روشن یا خاموشش کنن؛ خودت بزنش.",
                "Opening Wi-Fi settings."
            )
            handler.postDelayed({ startSafely(i) }, 800L)
            return true
        }

        // bluetooth
        if (full.contains("بلوتوث") || full.contains("bluetooth")) {
            reply(
                "تنظیمات بلوتوث رو باز می‌کنم. اندروید اجازه نمی‌ده برنامه‌ها مستقیم تغییرش بدن؛ خودت بزنش.",
                "Opening Bluetooth settings."
            )
            handler.postDelayed({ startSafely(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)) }, 800L)
            return true
        }

        // alarm
        if (full.contains("الارم") || full.contains("هشدار") || full.contains("بیدارم") ||
            full.contains("alarm") || full.contains("زنگساعت")
        ) {
            val clock = parseClock(raw)
            if (clock == null) {
                reply(
                    "ساعت آلارم رو متوجه نشدم. مثلاً بگو «آلارم برای ساعت هفت و نیم».",
                    "I didn't catch the alarm time."
                )
                return true
            }
            val h = clock.first
            val m = clock.second
            val i = Intent(AlarmClock.ACTION_SET_ALARM)
            i.putExtra(AlarmClock.EXTRA_HOUR, h)
            i.putExtra(AlarmClock.EXTRA_MINUTES, m)
            i.putExtra(AlarmClock.EXTRA_MESSAGE, "Friday")
            i.putExtra(AlarmClock.EXTRA_SKIP_UI, true)
            val said = if (m == 0) "ساعت $h" else "ساعت $h و $m دقیقه"
            reply("آلارم برای $said تنظیم شد", "Alarm set for $h:" + m.toString().padStart(2, '0'))
            handler.postDelayed({
                if (!startSafely(i)) {
                    reply("برنامه‌ی ساعت برای تنظیم آلارم پیدا نشد.", "No clock app found.")
                }
            }, 600L)
            return true
        }

        // timer
        if (full.contains("تایمر") || full.contains("timer") ||
            full.contains("زمانسنج") || full.contains("زمانشمار")
        ) {
            val secs = parseDurationSeconds(raw)
            if (secs <= 0) {
                reply(
                    "مدت تایمر رو متوجه نشدم. مثلاً بگو «تایمر ۵ دقیقه».",
                    "I didn't catch the timer length."
                )
                return true
            }
            val i = Intent(AlarmClock.ACTION_SET_TIMER)
            i.putExtra(AlarmClock.EXTRA_LENGTH, secs)
            i.putExtra(AlarmClock.EXTRA_MESSAGE, "Friday")
            i.putExtra(AlarmClock.EXTRA_SKIP_UI, true)
            reply("تایمر " + describeDuration(secs) + " تنظیم شد", "Timer set")
            handler.postDelayed({
                if (!startSafely(i)) {
                    reply("برنامه‌ی ساعت برای تنظیم تایمر پیدا نشد.", "No clock app found.")
                }
            }, 600L)
            return true
        }

        // sms
        if (tokens.any { it in smsWords } && tokens.any { it in sendVerbs }) {
            handleSms(raw)
            return true
        }
        return false
    }

    private fun handleSms(raw: String) {
        val words = raw.split(Regex("\\s+")).filter { it.isNotEmpty() }
        val vi = words.indexOfFirst { norm(it) in sendVerbs }
        val head = if (vi >= 0) words.take(vi) else words
        var bodyWords = if (vi >= 0) words.drop(vi + 1) else emptyList()
        if (bodyWords.isNotEmpty() && norm(bodyWords[0]) == "که") {
            bodyWords = bodyWords.drop(1)
        }
        val body = bodyWords.joinToString(" ")

        val headDigits = toAscii(head.joinToString(" ")).filter { it.isDigit() }
        val number: String
        val who: String
        if (headDigits.length >= 7) {
            number = headDigits
            who = headDigits
        } else {
            val query = head.map { norm(it) }
                .filter { it.isNotEmpty() && it !in smsStopWords }
                .joinToString("")
            if (query.isEmpty()) {
                reply("برای کی پیامک بفرستم؟", "Who should I text?")
                return
            }
            if (!hasPerm(Manifest.permission.READ_CONTACTS)) {
                requestPermissions(arrayOf(Manifest.permission.READ_CONTACTS), 2)
                reply(
                    "برای پیدا کردن مخاطب، اجازه‌ی خوندن مخاطبین رو بده و دوباره بگو.",
                    "I need permission to read your contacts."
                )
                return
            }
            val matches = findContacts(query)
            val names = matches.map { it.name }.distinct()
            if (matches.isEmpty()) {
                reply("مخاطبی به اسم «$query» پیدا نکردم.", "I couldn't find that contact.")
                return
            }
            if (names.size > 1) {
                reply(
                    "چند نفر پیدا شد: " + names.take(5).joinToString("، ") + ". اسم کامل‌تر رو بگو.",
                    "I found several matches. Please say the full name."
                )
                return
            }
            val c = pickNumber(matches)
            number = c.number
            who = c.name
        }

        val intent = Intent(Intent.ACTION_SENDTO, Uri.fromParts("smsto", number, null))
        if (body.isNotEmpty()) {
            intent.putExtra("sms_body", body)
        }
        reply(
            "پیامک برای $who آماده شد. دکمه‌ی ارسال رو خودت بزن.",
            "The message is ready. Tap send."
        )
        handler.postDelayed({
            if (!startSafely(intent)) {
                reply("برنامه‌ی پیامک پیدا نشد.", "No messaging app found.")
            }
        }, 800L)
    }

    // ---------------------------------------------------------------- Open apps

    private fun loadApps(): List<AppInfo> {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return packageManager.queryIntentActivities(intent, 0)
            .map {
                val label = it.loadLabel(packageManager).toString()
                AppInfo(label, it.activityInfo.packageName, norm(label))
            }
            .filter { it.pkg != packageName }
    }

    private fun findApp(query: String, full: String): AppInfo? {
        val apps = loadApps()
        val aliasTarget = resolveAlias(query)
        if (aliasTarget != null) {
            val at = norm(aliasTarget)
            if (at.length >= 2) {
                val hit = apps.firstOrNull { it.nLabel == at }
                    ?: apps.firstOrNull {
                        it.nLabel.contains(at) || it.pkg.lowercase(Locale.ROOT).contains(at)
                    }
                if (hit != null) return hit
            }
        }
        val nq = norm(query)

        // 1) exact label match
        if (nq.isNotEmpty()) {
            apps.firstOrNull { it.nLabel == nq }?.let { return it }
        }
        // 2) Persian aliases (واتساپ -> whatsapp, ...)
        for ((fa, keys) in aliases) {
            if (full.contains(fa)) {
                for (k in keys) {
                    apps.firstOrNull {
                        it.nLabel.contains(k) || it.pkg.lowercase(Locale.ROOT).contains(k)
                    }?.let { return it }
                }
            }
        }
        // 3) partial label match
        if (nq.length >= 2) {
            apps.filter {
                it.nLabel.length >= 2 && (nq.contains(it.nLabel) || it.nLabel.contains(nq))
            }.minByOrNull { it.nLabel.length }?.let { return it }
        }
        return null
    }

    private fun openApp(query: String, full: String) {
        if (query.isEmpty()) {
            reply("کدوم برنامه رو باز کنم؟", "Which app should I open?")
            return
        }
        val app = findApp(query, full)
        val launch = app?.let { packageManager.getLaunchIntentForPackage(it.pkg) }
        if (app == null || launch == null) {
            if (aiConfigured() && lastRaw.trim().split(Regex("\\s+")).size >= 4) {
                askAi(lastRaw)
            } else {
                reply("برنامه‌ای به اسم «$query» پیدا نکردم.", "I couldn't find that app.")
            }
            return
        }
        reply("دارم ${app.label} رو باز می‌کنم", "Opening ${app.label}")
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        handler.postDelayed({ startActivity(launch) }, 800)
    }

    // ---------------------------------------------------------------- Calls

    private fun loadContacts(): List<ContactInfo> {
        val list = ArrayList<ContactInfo>()
        val cursor = contentResolver.query(
            Phone.CONTENT_URI,
            arrayOf(Phone.DISPLAY_NAME, Phone.NUMBER),
            null, null, null
        ) ?: return list
        cursor.use {
            val ni = it.getColumnIndex(Phone.DISPLAY_NAME)
            val pi = it.getColumnIndex(Phone.NUMBER)
            while (it.moveToNext()) {
                val name = it.getString(ni) ?: continue
                val num = it.getString(pi) ?: continue
                val clean = cleanNumber(num)
                if (clean.isNotEmpty()) {
                    list.add(ContactInfo(name, clean, norm(name)))
                }
            }
        }
        return list
    }

    private fun findContacts(query: String): List<ContactInfo> {
        var q = query
        val alias = resolveAlias(query)
        if (alias != null) {
            val num = cleanNumber(alias)
            if (num.length >= 7) return listOf(ContactInfo(query, num, norm(query)))
            q = alias
        }
        val basic = findContactsBasic(q)
        if (basic.isNotEmpty()) return basic
        return findContactsByTransliteration(q)
    }

    /** Matches a Persian spoken name against contacts saved in English ("علی رضایی" ~ "Ali Rezaei"). */
    private fun findContactsByTransliteration(query: String): List<ContactInfo> {
        val qs = skeletonFa(query)
        if (qs.isEmpty()) return emptyList()
        val latin = loadContacts().filter { c -> c.name.any { it in 'a'..'z' || it in 'A'..'Z' } }
        if (latin.isEmpty()) return emptyList()
        if (qs.length >= 2) {
            val whole = latin.filter { skeletonLatin(it.name) == qs }
            if (whole.isNotEmpty()) return whole
        }
        val firstWord = latin.filter { c ->
            val w = c.name.trim().split(Regex("\\s+")).firstOrNull() ?: ""
            skeletonLatin(w) == qs
        }
        if (firstWord.isNotEmpty()) return firstWord
        if (qs.length >= 2) {
            return latin.filter { c ->
                c.name.trim().split(Regex("\\s+")).any { skeletonLatin(it) == qs }
            }
        }
        return emptyList()
    }

    private fun findContactsBasic(query: String): List<ContactInfo> {
        val nq = norm(query)
        if (nq.isEmpty()) return emptyList()
        val all = loadContacts()

        val exact = all.filter { it.nName == nq }
        if (exact.isNotEmpty()) return exact

        if (nq.length >= 2) {
            val partial = all.filter { it.nName.contains(nq) }
            if (partial.isNotEmpty()) return partial
        }
        return all.filter { it.nName.length >= 2 && nq.contains(it.nName) }
    }

    /** Prefers a mobile number when the same person has several numbers. */
    private fun pickNumber(list: List<ContactInfo>): ContactInfo =
        list.firstOrNull {
            it.number.startsWith("09") || it.number.startsWith("+989") ||
                it.number.startsWith("00989")
        } ?: list.first()

    private fun handleCall(raw: String, tokens: List<String>) {
        // a) a spoken / dictated phone number
        val digits = raw.filter { it.isDigit() }
            .map { it.digitToInt().toString() }
            .joinToString("")
        if (digits.length >= 7) {
            reply("دارم با شماره‌ی $digits تماس می‌گیرم", "Calling $digits")
            scheduleCall(digits)
            return
        }

        // b) a contact name
        val query = tokens.filter { it !in callStopWords }.joinToString("")
        if (query.isEmpty()) {
            reply("به کی زنگ بزنم؟", "Who should I call?")
            return
        }
        if (!hasPerm(Manifest.permission.READ_CONTACTS)) {
            requestPermissions(arrayOf(Manifest.permission.READ_CONTACTS), 2)
            reply(
                "برای پیدا کردن مخاطب، اجازه‌ی خوندن مخاطبین رو بده و دوباره بگو.",
                "I need permission to read your contacts."
            )
            return
        }

        val matches = findContacts(query)
        val names = matches.map { it.name }.distinct()
        when {
            matches.isEmpty() ->
                reply("مخاطبی به اسم «$query» پیدا نکردم.", "I couldn't find that contact.")

            names.size > 1 ->
                reply(
                    "چند نفر پیدا شد: " + names.take(5).joinToString("، ") +
                        ". اسم کامل‌تر رو بگو.",
                    "I found several matches. Please say the full name."
                )

            else -> {
                val c = pickNumber(matches)
                reply("دارم به ${c.name} زنگ می‌زنم", "Calling ${c.name}")
                scheduleCall(c.number)
            }
        }
    }

    private fun cancelLabel(left: Int): String =
        "✋  لغو تماس (" + left.toString().faDigits() + ")"

    /** Counts down 3 seconds so a wrong recognition can be cancelled, then places the call. */
    private fun scheduleCall(number: String) {
        cancelPending()
        val canCall = hasPerm(Manifest.permission.CALL_PHONE)
        val action = if (canCall) Intent.ACTION_CALL else Intent.ACTION_DIAL
        val intent = Intent(action, Uri.fromParts("tel", number, null))
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

        var left = 3
        cancelButton.text = cancelLabel(left)
        cancelButton.visibility = View.VISIBLE
        if (!canCall) {
            statusView.text = statusView.text.toString() +
                "\n\n(اجازه‌ی تماس مستقیم داده نشده؛ صفحه‌ی شماره‌گیر باز می‌شه)"
        }

        val r = object : Runnable {
            override fun run() {
                left--
                if (left > 0) {
                    cancelButton.text = cancelLabel(left)
                    handler.postDelayed(this, 1000L)
                } else {
                    pendingCall = null
                    cancelButton.visibility = View.GONE
                    startActivity(intent)
                }
            }
        }
        pendingCall = r
        handler.postDelayed(r, 1000L)
    }

    private fun cancelPending() {
        pendingCall?.let { handler.removeCallbacks(it) }
        pendingCall = null
        cancelButton.visibility = View.GONE
    }

    // ---------------------------------------------------------------- AI brain

    private fun aiKey(): String = aiPrefs.getString("key", "") ?: ""
    private fun aiUrl(): String = aiPrefs.getString("url", AiClient.DEFAULT_URL) ?: AiClient.DEFAULT_URL
    private fun aiModel(): String =
        aiPrefs.getString("model", AiClient.DEFAULT_MODEL) ?: AiClient.DEFAULT_MODEL

    private fun aiConfigured(): Boolean = aiKey().isNotBlank()

    private fun aiSystemPrompt(): String {
        val now = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date())
        return "تو «فرایدی» هستی، یه دستیار صوتی فارسی‌زبان روی گوشی. " +
            "جواب‌ها رو ساده، دوستانه و خیلی کوتاه بده (حداکثر دو یا سه جمله)، چون با صدا خونده می‌شن. " +
            "از فرمت مارکداون، فهرست، جدول و ایموجی استفاده نکن. اگه جواب رو نمی‌دونی، صادقانه بگو. " +
            "به زبانی جواب بده که کاربر باهاش پرسیده. تاریخ و ساعت فعلی: " + now
    }

    private fun cleanAnswer(s: String): String =
        s.replace(Regex("[*#`_>]+"), "")
            .replace(Regex("(?m)^\\s*[-•]\\s+"), "")
            .replace(Regex("\\n{2,}"), "\n")
            .trim()
            .take(3500)

    /** Sends a free-form question to the AI service and shows/speaks the answer. */
    private fun askAi(question: String) {
        if (!aiConfigured()) {
            reply(
                "متوجه نشدم. بگو «واتساپ رو باز کن»، «ساعت و تاریخ» یا «به علی زنگ بزن». " +
                    "برای سؤال‌های آزاد، هوش مصنوعی رو از دکمه‌ی ⚙️ فعال کن.",
                "Sorry, I didn't understand."
            )
            return
        }
        val id = ++aiCounter
        orb.listening = true
        setStatus("دارم فکر می‌کنم...")

        val msgs = ArrayList<Pair<String, String>>()
        msgs.add(Pair("system", aiSystemPrompt()))
        msgs.addAll(aiHistory)
        msgs.add(Pair("user", question))
        val url = aiUrl()
        val key = aiKey()
        val model = aiModel()

        Thread {
            val res = AiClient.chat(url, key, model, msgs)
            runOnUiThread {
                if (id != aiCounter || isDestroyed) return@runOnUiThread
                orb.listening = false
                val answer = res.text
                if (answer != null) {
                    val clean = cleanAnswer(answer)
                    aiHistory.add(Pair("user", question))
                    aiHistory.add(Pair("assistant", clean))
                    while (aiHistory.size > 8) aiHistory.removeAt(0)
                    reply(clean, "The answer is on the screen.")
                } else {
                    reply(res.error ?: "خطای نامشخص", "The AI request failed.")
                }
            }
        }.start()
    }

    private fun showAiSettings() {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(20), dp(8), dp(20), 0)

        fun addField(hint: String, value: String, secret: Boolean): EditText {
            val e = EditText(this)
            e.hint = hint
            e.setText(value)
            e.inputType = if (secret) {
                InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            } else {
                InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            }
            box.addView(e, LinearLayout.LayoutParams(MP, WC))
            return e
        }

        val keyField = addField("کلید API (از پنل GapGPT)", aiKey(), true)
        val urlField = addField("آدرس سرویس (Base URL)", aiUrl(), false)
        val modelField = addField("نام مدل (مثلاً gpt-4o)", aiModel(), false)

        val result = TextView(this)
        result.textSize = 13f
        result.setPadding(0, dp(10), 0, 0)
        box.addView(result, LinearLayout.LayoutParams(MP, WC))

        fun save() {
            aiPrefs.edit()
                .putString("key", keyField.text.toString().trim())
                .putString("url", urlField.text.toString().trim().ifEmpty { AiClient.DEFAULT_URL })
                .putString("model", modelField.text.toString().trim().ifEmpty { AiClient.DEFAULT_MODEL })
                .apply()
        }

        val dlg = AlertDialog.Builder(this)
            .setTitle("هوش مصنوعی (GapGPT)")
            .setView(box)
            .setPositiveButton("ذخیره", null)
            .setNeutralButton("تست", null)
            .setNegativeButton("بستن", null)
            .create()
        dlg.show()

        // override the clicks so the dialog stays open while testing
        dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
            save()
            dlg.dismiss()
            setStatus(
                if (aiConfigured()) "تنظیمات ذخیره شد. حالا هر سؤالی بپرس." else "کلید خالیه؛ هوش مصنوعی غیرفعاله."
            )
        }
        dlg.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
            save()
            if (!aiConfigured()) {
                result.text = "اول کلید API رو وارد کن."
                return@setOnClickListener
            }
            result.text = "در حال تست..."
            val url = aiUrl()
            val key = aiKey()
            val model = aiModel()
            Thread {
                val res = AiClient.chat(
                    url, key, model,
                    listOf(Pair("user", "سلام! فقط بگو: کار می‌کنم."))
                )
                runOnUiThread {
                    val ok = res.text
                    result.text = if (ok != null) "✅ " + ok else "❌ " + (res.error ?: "")
                }
            }.start()
        }
    }

    // ---------------------------------------------------------------- Settings menu

    private val settingsPrefs by lazy { getSharedPreferences("friday_settings", Context.MODE_PRIVATE) }

    private fun showSettingsMenu() {
        val items = arrayOf("🤖 هوش مصنوعی", "👤 اسم‌های دلخواه", "🔊 صدا", "ℹ️ راهنمای دستورها")
        AlertDialog.Builder(this)
            .setTitle("تنظیمات فرایدی")
            .setItems(items) { _, which ->
                when (which) {
                    0 -> showAiSettings()
                    1 -> showAliasSettings()
                    2 -> showVoiceSettings()
                    else -> showHelp()
                }
            }
            .show()
    }

    private fun showHelp() {
        val text = "• «واتساپ رو باز کن»\n" +
            "• «به علی زنگ بزن» / «به علی پیامک بده که ...»\n" +
            "• «ساعت چنده؟» / «تاریخ امروز»\n" +
            "• «آلارم ساعت ۷ و نیم» / «تایمر ۵ دقیقه»\n" +
            "• «چراغ قوه رو روشن کن»\n" +
            "• «مسیریابی به میدان آزادی» / «برو به ...»\n" +
            "• «آهنگ بعدی» / «پخش» / «مکث» / «آهنگ ... رو پخش کن»\n" +
            "• «صدا رو زیاد کن» / «صدا رو ۵۰ درصد بذار»\n" +
            "• «جستجو کن ...»\n" +
            "• «۱۰ دقیقه دیگه یادم بنداز نون رو دربیارم»\n" +
            "• «ساعت ۵ یادم بنداز دارو بخورم»\n" +
            "• «رویداد فردا ساعت ۱۰ جلسه با علی توی تقویم»\n" +
            "• هر سؤال دیگه‌ای به هوش مصنوعی می‌ره (اگه فعال باشه)"
        AlertDialog.Builder(this)
            .setTitle("راهنمای دستورها")
            .setMessage(text)
            .setPositiveButton("باشه", null)
            .show()
    }

    // ---- custom names ("مامان = Mom")

    private fun aliasList(): List<Pair<String, String>> {
        val text = settingsPrefs.getString("aliases", "") ?: ""
        val out = ArrayList<Pair<String, String>>()
        for (line in text.split("\n")) {
            val parts = line.split(Regex("\\s*(=|->|→|:)\\s*"), limit = 2)
            if (parts.size == 2) {
                val k = norm(parts[0])
                val v = parts[1].trim()
                if (k.isNotEmpty() && v.isNotEmpty()) out.add(Pair(k, v))
            }
        }
        return out
    }

    /** If [query] is exactly one of the user's custom names, returns what it stands for. */
    private fun resolveAlias(query: String): String? {
        val nq = norm(query)
        if (nq.isEmpty()) return null
        return aliasList().firstOrNull { it.first == nq }?.second
    }

    private fun showAliasSettings() {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(20), dp(8), dp(20), 0)

        val field = EditText(this)
        field.setText(settingsPrefs.getString("aliases", "") ?: "")
        field.hint = "مامان = Mom\nاینستا = Instagram\nخونه = تهران، میدان آزادی"
        field.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
        field.minLines = 6
        field.gravity = Gravity.TOP
        box.addView(field, LinearLayout.LayoutParams(MP, WC))

        AlertDialog.Builder(this)
            .setTitle("اسم‌های دلخواه")
            .setMessage("هر خط: اسم دلخواه = مقصد\n(مقصد: اسم مخاطب، شماره‌ی تلفن، اسم برنامه یا آدرس)")
            .setView(box)
            .setPositiveButton("ذخیره") { _, _ ->
                settingsPrefs.edit().putString("aliases", field.text.toString()).apply()
                setStatus("اسم‌های دلخواه ذخیره شد.")
            }
            .setNegativeButton("بستن", null)
            .show()
    }

    // ---- voice

    private fun showVoiceSettings() {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(20), dp(8), dp(20), 0)

        val speakBox = CheckBox(this)
        speakBox.text = "خوندن جواب‌ها با صدا"
        speakBox.isChecked = settingsPrefs.getBoolean("speak", true)
        box.addView(speakBox, LinearLayout.LayoutParams(MP, WC))

        val rateLabel = TextView(this)
        val rateBar = SeekBar(this)
        rateBar.max = 20
        rateBar.progress = Math.round((settingsPrefs.getFloat("rate", 0.85f) - 0.5f) / 0.05f)
        val pitchLabel = TextView(this)
        val pitchBar = SeekBar(this)
        pitchBar.max = 20
        pitchBar.progress = Math.round((settingsPrefs.getFloat("pitch", 1.0f) - 0.5f) / 0.05f)

        fun showValues() {
            rateLabel.text = "سرعت صدا: " +
                String.format(Locale.US, "%.2f", 0.5f + rateBar.progress * 0.05f)
            pitchLabel.text = "زیر و بمی صدا: " +
                String.format(Locale.US, "%.2f", 0.5f + pitchBar.progress * 0.05f)
        }

        val listener = object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                showValues()
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        }
        rateBar.setOnSeekBarChangeListener(listener)
        pitchBar.setOnSeekBarChangeListener(listener)
        showValues()

        val labelParams = LinearLayout.LayoutParams(MP, WC)
        labelParams.topMargin = dp(14)
        box.addView(rateLabel, labelParams)
        box.addView(rateBar, LinearLayout.LayoutParams(MP, WC))
        val labelParams2 = LinearLayout.LayoutParams(MP, WC)
        labelParams2.topMargin = dp(14)
        box.addView(pitchLabel, labelParams2)
        box.addView(pitchBar, LinearLayout.LayoutParams(MP, WC))

        fun save() {
            settingsPrefs.edit()
                .putBoolean("speak", speakBox.isChecked)
                .putFloat("rate", 0.5f + rateBar.progress * 0.05f)
                .putFloat("pitch", 0.5f + pitchBar.progress * 0.05f)
                .apply()
        }

        val dlg = AlertDialog.Builder(this)
            .setTitle("صدا")
            .setView(box)
            .setPositiveButton("ذخیره", null)
            .setNeutralButton("پخش نمونه", null)
            .setNegativeButton("بستن", null)
            .create()
        dlg.show()
        dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
            save()
            dlg.dismiss()
            setStatus("تنظیمات صدا ذخیره شد.")
        }
        dlg.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
            save()
            speak("سلام! من فرایدی هستم. صدای من الان همین‌طوره.", "Hello! This is how I sound now.", true)
        }
    }

    // ---------------------------------------------------------------- Extra commands

    private fun hasAny(s: String, vararg words: String): Boolean = words.any { s.contains(it) }

    private fun wordsOf(raw: String): List<String> =
        raw.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }

    private val navStop = setOf(
        "رو", "را", "به", "تا", "to", "برای", "منو", "من", "لطفا", "فرایدی", "friday", "هی",
        "از", "اینجا", "مقصد", "نشون", "بده", "بگیر", "پیدا", "کن", "بزن"
    )
    private val musicStop = setOf(
        "اهنگ", "موزیک", "موسیقی", "music", "song", "پخش", "play", "کن", "رو", "را", "برام",
        "از", "فرایدی", "friday", "هی", "لطفا", "بذار", "بزن", "یه", "یک"
    )
    private val searchWords = setOf("جستجو", "جستوجو", "سرچ", "search")
    private val searchStop = searchWords + setOf(
        "کن", "کنید", "رو", "را", "برام", "برای", "من", "در", "توی", "تو", "اینترنت", "وب",
        "گوگل", "google", "for", "the", "web", "لطفا", "فرایدی", "friday", "هی", "درباره", "دربارهی"
    )
    private val reminderNoise = setOf(
        "یادم", "بنداز", "یاداوری", "یاداور", "کن", "کنید", "بذار", "بزن", "بساز", "اضافه", "رو",
        "را", "برام", "برای", "من", "فرایدی", "friday", "هی", "لطفا", "که", "ساعت", "دقیقه",
        "ثانیه", "دیگه", "دیگر", "و", "نیم", "ربع", "صبح", "ظهر", "عصر", "شب", "بعدازظهر",
        "فردا", "پسفردا", "امروز", "توی", "تو", "تقویم", "رویداد", "remind", "me", "to", "at",
        "in", "event", "add", "calendar"
    )

    private fun hasAudioReadPermission(): Boolean = when {
        Build.VERSION.SDK_INT >= 33 -> hasPerm(Manifest.permission.READ_MEDIA_AUDIO)
        Build.VERSION.SDK_INT >= 23 -> hasPerm(Manifest.permission.READ_EXTERNAL_STORAGE)
        else -> true
    }

    private fun requestAudioReadPermission(query: String) {
        pendingLocalMusicQuery = query
        val permission = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
            else Manifest.permission.READ_EXTERNAL_STORAGE
        requestPermissions(arrayOf(permission), 6)
        reply("برای جست‌وجوی آهنگ‌های داخل گوشی، اجازه‌ی دسترسی به فایل‌های صوتی رو بده.", "Please allow access to audio files.")
    }

    /** Navigation, volume, music, notes, downloads, web search, reminders & calendar. */
    private fun handleExtraCommands(raw: String, tokens: List<String>, full: String): Boolean {
        if (handleNoteCommand(raw, full)) return true
        if (handleDownloadCommand(raw, full)) return true
        if (full.contains("صدا") || full.contains("ولوم") || full.contains("volume")) {
            if (handleVolume(raw, tokens, full)) return true
        }
        if (handleMusic(raw, tokens, full)) return true
        if (handleSearch(raw, tokens)) return true
        if (handleReminder(raw, tokens, full)) return true
        if (handleNavigation(raw)) return true
        return false
    }

    private fun handleNoteCommand(raw: String, full: String): Boolean {
        val wantsNote = hasAny(full, "یادداشت", "نوت", "note", "notes") &&
            hasAny(full, "بنویس", "بنویسم", "یادداشتکن", "ذخیرهکن", "ثبتکن", "بنویسداخل", "write", "save", "اضافهکن")
        if (!wantsNote) return false
        val content = raw.replace(Regex("(?i)friday|فرایدی|هی"), " ")
            .replace(Regex("یادداشت|یادداشت کن|نوت|note|notes|بنویس|بنویسم|بنویس داخل|داخل|توی|تو|برام|برای من|لطفا|لطفاً|ذخیره کن|ثبت کن|اضافه کن|write|save", RegexOption.IGNORE_CASE), " ")
            .trim().trim(':', '،', ',', ' ', '"', '«', '»')
        if (content.isBlank()) {
            reply("متنی که باید توی یادداشت بنویسم رو بگو.", "What should I write in the note?")
            return true
        }
        val create = Intent("android.intent.action.CREATE_NOTE").apply {
            putExtra(Intent.EXTRA_TEXT, content)
            putExtra("android.intent.extra.TEXT", content)
        }
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, content)
        }
        reply("دارم متن رو به برنامه‌ی یادداشت می‌فرستم.", "Sending text to a notes app.")
        handler.postDelayed({
            if (!startSafely(create)) {
                // Android has no universal API to silently save into every vendor's Notes app.
                if (!startSafely(Intent.createChooser(send, "انتخاب برنامه‌ی یادداشت"))) {
                    reply("برنامه‌ای برای یادداشت پیدا نشد.", "No notes app found.")
                }
            }
        }, 500L)
        return true
    }

    /** Downloads a direct HTTP(S) media URL with Android DownloadManager, without a second confirmation. */
    private fun handleDownloadCommand(raw: String, full: String): Boolean {
        val wantsDownload = hasAny(full, "دانلود", "بارگیری", "download")
        if (!wantsDownload) return false
        val urlMatch = Regex("https?://[^\\s<>\"']+", RegexOption.IGNORE_CASE).find(raw)
        if (urlMatch == null) {
            reply("برای دانلود خودکار، لینک مستقیم فایل رو هم در فرمان بگو. دانلود از سایت‌های جست‌وجو بدون لینک مستقیم قابل‌اعتماد نیست.", "Please provide a direct media URL.")
            return true
        }
        val url = urlMatch.value.trimEnd('.', ',', '،', ')', ']')
        val uri = try { Uri.parse(url) } catch (_: Exception) { null }
        if (uri == null || (uri.scheme != "https" && uri.scheme != "http") || uri.host.isNullOrBlank()) {
            reply("لینک دانلود معتبر نیست.", "Invalid download URL.")
            return true
        }
        try {
            val request = DownloadManager.Request(uri)
                .setTitle(uri.lastPathSegment?.takeIf { it.isNotBlank() } ?: "Friday media")
                .setDescription("دانلود به درخواست کاربر از Friday")
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setAllowedOverMetered(true)
                .setAllowedOverRoaming(false)
            if (Build.VERSION.SDK_INT >= 29) {
                request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, uri.lastPathSegment?.takeIf { it.isNotBlank() } ?: "friday-media")
            }
            val dm = getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
            dm.enqueue(request)
            reply("دانلود شروع شد. نتیجه رو از اعلان‌های گوشی می‌تونی ببینی.", "Download started.")
        } catch (e: Exception) {
            reply("نتونستم دانلود رو شروع کنم. لینک یا دسترسی شبکه رو بررسی کن.", "Could not start download.")
        }
        return true
    }

    private fun launchMusicSearch(query: String) {
        val i = Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH).apply {
            putExtra(SearchManager.QUERY, query)
            putExtra(MediaStore.EXTRA_MEDIA_FOCUS, "vnd.android.cursor.item/*")
        }
        if (!startSafely(i)) reply("آهنگ پیدا نشد و برنامه‌ی موسیقی سازگار در دسترس نیست.", "No matching song or compatible music app found.")
    }

    private fun playLocalMusic(query: String): Boolean {
        if (query.isBlank()) {
            reply("اسم آهنگ رو متوجه نشدم.", "Please say a song title.")
            return false
        }
        if (!hasAudioReadPermission()) {
            requestAudioReadPermission(query)
            return false
        }
        var selectedUri: Uri? = null
        var selectedTitle = ""
        try {
            val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
            val projection = arrayOf(MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST, MediaStore.Audio.Media.DISPLAY_NAME)
            val qNorm = norm(query)
            contentResolver.query(collection, projection, "${MediaStore.Audio.Media.IS_MUSIC} != 0", null, "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC")?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
                val artistCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
                val displayCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DISPLAY_NAME)
                var best = -1
                while (cursor.moveToNext()) {
                    val title = cursor.getString(titleCol) ?: ""
                    val artist = cursor.getString(artistCol) ?: ""
                    val display = cursor.getString(displayCol) ?: ""
                    val hay = norm("$title $artist $display")
                    val score = when {
                        hay == qNorm -> 100
                        title.isNotBlank() && norm(title) == qNorm -> 95
                        hay.contains(qNorm) -> 80
                        qNorm.contains(norm(title)) && title.isNotBlank() -> 55
                        qNorm.split(Regex("\\s+")).count { it.length > 1 && hay.contains(it) } > 0 -> 30
                        else -> 0
                    }
                    if (score > best && score > 0) {
                        best = score
                        selectedUri = Uri.withAppendedPath(collection, cursor.getLong(idCol).toString())
                        selectedTitle = title.ifBlank { display }
                    }
                }
            }
        } catch (_: Exception) {
            reply("نتونستم به فهرست موسیقی گوشی دسترسی پیدا کنم.", "Could not read local music.")
            return true
        }
        val uri = selectedUri
        if (uri == null) {
            return false
        }
        try {
            localPlayer?.release()
            localPlayer = MediaPlayer().apply {
                setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
                setDataSource(this@MainActivity, uri)
                setOnPreparedListener { it.start() }
                setOnCompletionListener { it.release(); if (localPlayer === it) localPlayer = null }
                setOnErrorListener { mp, _, _ -> mp.release(); if (localPlayer === mp) localPlayer = null; reply("پخش این فایل ناموفق بود.", "Playback failed."); true }
                prepareAsync()
            }
            reply("دارم آهنگ «$selectedTitle» رو از گوشی پخش می‌کنم.", "Playing local music.")
            return true
        } catch (_: Exception) {
            localPlayer?.release()
            localPlayer = null
            reply("این فایل قابل پخش نیست.", "This audio file cannot be played.")
            return true
        }
    }

    private fun handleVolume(raw: String, tokens: List<String>, full: String): Boolean {
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        val num = toAscii(raw).split(Regex("\\s+")).firstNotNullOfOrNull { numberToken(it) }
        if (num != null && hasAny(full, "درصد", "percent")) {
            val p = num.coerceIn(0, 100)
            am.setStreamVolume(
                AudioManager.STREAM_MUSIC, Math.round(max * p / 100f), AudioManager.FLAG_SHOW_UI
            )
            reply("صدا روی $p درصد تنظیم شد", "Volume set to $p percent")
            return true
        }
        val raise = setOf("زیاد", "زیادتر", "بیشتر", "بلند", "بلندتر", "بالا", "بالاتر", "louder", "raise", "increase", "up")
        val lower = setOf("کم", "کمتر", "اروم", "ارومتر", "پایین", "پایینتر", "quieter", "lower", "decrease", "down")
        val mute = setOf("بیصدا", "قطع", "mute", "سایلنت", "silent")
        val unmute = setOf("وصل", "unmute")
        when {
            tokens.any { it in unmute } -> {
                am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_UNMUTE, AudioManager.FLAG_SHOW_UI)
                reply("صدا وصل شد", "Unmuted")
            }
            tokens.any { it in mute } -> {
                am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, AudioManager.FLAG_SHOW_UI)
                reply("صدا قطع شد", "Muted")
            }
            tokens.any { it in raise } -> {
                am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
                reply("صدا بلندتر شد", "Volume up")
            }
            tokens.any { it in lower } -> {
                am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
                reply("صدا کمتر شد", "Volume down")
            }
            else -> return false
        }
        return true
    }

    private fun sendMediaKey(code: Int) {
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
    }

    private fun handleMusic(raw: String, tokens: List<String>, full: String): Boolean {
        val musicWord = hasAny(full, "اهنگ", "موزیک", "موسیقی", "music", "song")
        if (!musicWord && tokens.size > 3) return false

        if (tokens.any { it == "بعدی" || it == "next" || it == "skip" }) {
            sendMediaKey(KeyEvent.KEYCODE_MEDIA_NEXT)
            reply("آهنگ بعدی", "Next track")
            return true
        }
        if (tokens.any { it == "قبلی" || it == "previous" || it == "prev" }) {
            sendMediaKey(KeyEvent.KEYCODE_MEDIA_PREVIOUS)
            reply("آهنگ قبلی", "Previous track")
            return true
        }
        if (tokens.any { it == "مکث" || it == "pause" || it == "وایسا" || it == "متوقف" || it == "stop" }) {
            try { if (localPlayer?.isPlaying == true) localPlayer?.pause() else sendMediaKey(KeyEvent.KEYCODE_MEDIA_PAUSE) } catch (_: Exception) { sendMediaKey(KeyEvent.KEYCODE_MEDIA_PAUSE) }
            reply("متوقف شد", "Paused")
            return true
        }
        if (tokens.any { it == "پخش" || it == "play" || it == "ادامه" }) {
            val query = wordsOf(raw).filter { norm(it) !in musicStop }.joinToString(" ")
            if (query.isNotEmpty() && (musicWord || tokens.size > 3)) {
                // Prefer the user's own music library; if no local match exists, try installed music apps.
                if (hasAudioReadPermission()) {
                    val found = playLocalMusic(query)
                    if (found) return true
                } else {
                    requestAudioReadPermission(query)
                    return true
                }
                handler.postDelayed({ launchMusicSearch(query) }, 500L)
                return true
            }
            if (localPlayer != null && tokens.any { it in setOf("پخش", "play", "ادامه") }) {
                try { localPlayer?.start(); reply("پخش ادامه پیدا کرد.", "Playback resumed."); return true } catch (_: Exception) { }
            }
            sendMediaKey(KeyEvent.KEYCODE_MEDIA_PLAY)
            reply("پخش", "Playing")
            return true
        }
        return false
    }

    private fun handleSearch(raw: String, tokens: List<String>): Boolean {
        if (tokens.none { it in searchWords }) return false
        val q = wordsOf(raw).filter { norm(it) !in searchStop }.joinToString(" ")
        if (q.isEmpty()) {
            reply("چی رو جستجو کنم؟", "What should I search for?")
            return true
        }
        reply("دارم «$q» رو جستجو می‌کنم", "Searching")
        val web = Intent(Intent.ACTION_WEB_SEARCH)
        web.putExtra(SearchManager.QUERY, q)
        val view = Intent(
            Intent.ACTION_VIEW,
            Uri.parse("https://www.google.com/search?q=" + Uri.encode(q))
        )
        handler.postDelayed({
            if (!startSafely(web) && !startSafely(view)) {
                setStatus("برنامه‌ای برای جستجو پیدا نشد.")
            }
        }, 800L)
        return true
    }

    private fun handleReminder(raw: String, tokens: List<String>, full: String): Boolean {
        val isReminder = hasAny(full, "یادمبنداز", "یاداوری", "یاداور") || tokens.contains("remind")
        val isEvent = full.contains("رویداد") || tokens.contains("event") ||
            (full.contains("تقویم") && hasAny(full, "بساز", "اضافه", "بذار"))
        if (!isReminder && !isEvent) return false

        val dayOffset = when {
            full.contains("پسفردا") -> 2
            full.contains("فردا") -> 1
            else -> 0
        }
        val clock = parseClock(raw)
        val secs = parseDurationSeconds(raw)
        val title = wordsOf(raw).filter { w ->
            val n = norm(w)
            n.isNotEmpty() && n !in reminderNoise && numberToken(n) == null && !n.all { it.isDigit() }
        }.joinToString(" ").ifEmpty { "Friday" }

        // a calendar event (or anything for tomorrow or later): prefill the calendar, you press save
        if (isEvent || dayOffset >= 1) {
            val cal = Calendar.getInstance()
            cal.add(Calendar.DAY_OF_YEAR, dayOffset)
            if (clock != null) {
                cal.set(Calendar.HOUR_OF_DAY, clock.first)
                cal.set(Calendar.MINUTE, clock.second)
                cal.set(Calendar.SECOND, 0)
            } else if (secs > 0) {
                cal.add(Calendar.SECOND, secs)
            }
            val begin = cal.timeInMillis
            val i = Intent(Intent.ACTION_INSERT)
            i.data = CalendarContract.Events.CONTENT_URI
            i.putExtra(CalendarContract.Events.TITLE, title)
            if (clock != null || secs > 0) {
                i.putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, begin)
                i.putExtra(CalendarContract.EXTRA_EVENT_END_TIME, begin + 3600000L)
            }
            reply(
                "دارم رویداد «$title» رو توی تقویم آماده می‌کنم. ذخیره‌اش رو خودت بزن.",
                "Opening the calendar."
            )
            handler.postDelayed({
                if (!startSafely(i)) reply("برنامه‌ی تقویم پیدا نشد.", "No calendar app found.")
            }, 800L)
            return true
        }

        // a simple reminder today: a labeled timer or alarm
        if (secs > 0) {
            val i = Intent(AlarmClock.ACTION_SET_TIMER)
            i.putExtra(AlarmClock.EXTRA_LENGTH, secs)
            i.putExtra(AlarmClock.EXTRA_MESSAGE, title)
            i.putExtra(AlarmClock.EXTRA_SKIP_UI, true)
            reply("باشه، " + describeDuration(secs) + " دیگه یادت می‌ندازم: " + title, "Reminder set")
            handler.postDelayed({
                if (!startSafely(i)) reply("برنامه‌ی ساعت پیدا نشد.", "No clock app found.")
            }, 800L)
        } else if (clock != null) {
            val h = clock.first
            val m = clock.second
            val i = Intent(AlarmClock.ACTION_SET_ALARM)
            i.putExtra(AlarmClock.EXTRA_HOUR, h)
            i.putExtra(AlarmClock.EXTRA_MINUTES, m)
            i.putExtra(AlarmClock.EXTRA_MESSAGE, title)
            i.putExtra(AlarmClock.EXTRA_SKIP_UI, true)
            val said = if (m == 0) "ساعت $h" else "ساعت $h و $m دقیقه"
            reply("باشه، $said یادت می‌ندازم: $title", "Reminder set")
            handler.postDelayed({
                if (!startSafely(i)) reply("برنامه‌ی ساعت پیدا نشد.", "No clock app found.")
            }, 800L)
        } else {
            reply(
                "برای چه ساعتی یادآوری کنم؟ مثلاً بگو «ساعت ۵ یادم بنداز دارو بخورم».",
                "What time should I remind you?"
            )
        }
        return true
    }

    private fun handleNavigation(raw: String): Boolean {
        val words = wordsOf(raw)
        val n = words.map { norm(it) }
        var start = -1
        for (idx in n.indices) {
            val w = n[idx]
            val next = n.getOrNull(idx + 1)
            if (w == "مسیریابی" || w == "navigate" || w == "directions" ||
                (w == "مسیر" && (next == "به" || next == "تا" || next == "to"))
            ) {
                start = idx + 1
                break
            }
            if (w == "برو" && next == "به") {
                start = idx + 2
                break
            }
        }
        if (start < 0) return false

        val dest = words.drop(start).filter { norm(it) !in navStop }.joinToString(" ")
        if (dest.isEmpty()) {
            reply("کجا بروم؟", "Where to?")
            return true
        }
        if (dest.split(" ").size > 6) return false // probably a normal sentence, let the AI have it

        // "برو به تلگرام" -> an installed app?
        val app = findApp(norm(dest), norm(dest))
        val launch = app?.let { packageManager.getLaunchIntentForPackage(it.pkg) }
        if (app != null && launch != null) {
            reply("دارم ${app.label} رو باز می‌کنم", "Opening ${app.label}")
            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            handler.postDelayed({ startActivity(launch) }, 800L)
            return true
        }

        val target = resolveAlias(dest) ?: dest
        val geo = Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(target)))
        reply("دارم «$target» رو توی نقشه باز می‌کنم", "Opening the map")
        handler.postDelayed({
            if (!startSafely(geo)) reply("برنامه‌ی نقشه پیدا نشد.", "No maps app found.")
        }, 800L)
        return true
    }

    // ---------------------------------------------------------------- Time & date

    private fun answerTimeDate(wantTime: Boolean, wantDate: Boolean) {
        val cal = Calendar.getInstance()
        val h = cal.get(Calendar.HOUR_OF_DAY)
        val min = cal.get(Calendar.MINUTE)

        val weekday = faWeekdays[cal.get(Calendar.DAY_OF_WEEK) - 1]
        val (year, jm, day) = gregorianToJalali(
            cal.get(Calendar.YEAR),
            cal.get(Calendar.MONTH) + 1,
            cal.get(Calendar.DAY_OF_MONTH)
        )
        val month = faMonths[jm - 1]

        val faTime = if (min == 0) "ساعت $h است" else "ساعت $h و $min دقیقه است"
        val faDate = "امروز $weekday $day $month $year است"

        val now = Date()
        val enTime = "It is " + SimpleDateFormat("h:mm a", Locale.US).format(now)
        val enDate = "Today is " + SimpleDateFormat("EEEE, MMMM d, yyyy", Locale.US).format(now)

        val fa = listOfNotNull(
            if (wantTime) faTime else null,
            if (wantDate) faDate else null
        ).joinToString(". ")
        val en = listOfNotNull(
            if (wantTime) enTime else null,
            if (wantDate) enDate else null
        ).joinToString(". ")

        reply(fa, en)
    }

    // ---------------------------------------------------------------- Speaking

    /** Shows [fa] on screen and speaks it (Persian voice if available, else English [en]). */
    private fun reply(fa: String, en: String) {
        val spokeFa = speak(fa, en)
        if (fromWake) scheduleLockClose()
        setStatus(
            fa.faDigits() +
                if (spokeFa) "" else "\n\n(صدای فارسی روی این گوشی نصب نیست؛ انگلیسی می‌گم)"
        )
    }

    private fun speak(fa: String, en: String, force: Boolean = false): Boolean {
        val engine = tts ?: return false
        if (!ttsReady) return false
        if (!force && !settingsPrefs.getBoolean("speak", true)) return true
        val faOk = engine.isLanguageAvailable(Locale("fa")) >= TextToSpeech.LANG_AVAILABLE
        return if (faOk) {
            engine.setLanguage(Locale("fa"))
            engine.setPitch(settingsPrefs.getFloat("pitch", 1.0f))
            engine.setSpeechRate(settingsPrefs.getFloat("rate", 0.85f))
            engine.speak(spokenFa(fa), TextToSpeech.QUEUE_FLUSH, null, "friday")
            true
        } else {
            engine.setLanguage(Locale.US)
            engine.setSpeechRate(1.0f)
            engine.speak(en, TextToSpeech.QUEUE_FLUSH, null, "friday")
            false
        }
    }
}
