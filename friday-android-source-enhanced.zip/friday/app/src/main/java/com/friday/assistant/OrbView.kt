package com.friday.assistant

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.os.SystemClock
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.PI
import kotlin.math.sin

/** A glowing, breathing orb with a mic icon. Pulses faster and turns pink while listening. */
class OrbView(context: Context) : View(context) {

    var listening: Boolean = false
        set(value) {
            field = value
            invalidate()
        }

    private var t = 0f
    private var last = 0L

    private val cyan = Color.parseColor("#29D8FF")
    private val blue = Color.parseColor("#3A6BFF")
    private val pink = Color.parseColor("#FF4DA6")
    private val violet = Color.parseColor("#7B2FF7")
    private val ink = Color.parseColor("#0B1020")

    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val corePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val iconFill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val iconStroke = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()

    private val animator: ValueAnimator = ValueAnimator.ofFloat(0f, 1f)

    init {
        ringPaint.style = Paint.Style.STROKE
        iconFill.style = Paint.Style.FILL
        iconFill.color = ink
        iconStroke.style = Paint.Style.STROKE
        iconStroke.color = ink
        iconStroke.strokeCap = Paint.Cap.ROUND

        animator.duration = 1000L
        animator.repeatCount = ValueAnimator.INFINITE
        animator.interpolator = LinearInterpolator()
        animator.addUpdateListener {
            val now = SystemClock.uptimeMillis()
            if (last == 0L) last = now
            val dt = (now - last) / 1000f
            last = now
            t += dt * (if (listening) 1.6f else 0.45f)
            invalidate()
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        last = 0L
        animator.start()
    }

    override fun onDetachedFromWindow() {
        animator.cancel()
        super.onDetachedFromWindow()
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val w = View.MeasureSpec.getSize(widthMeasureSpec)
        val h = View.MeasureSpec.getSize(heightMeasureSpec)
        val s = if (h <= 0) w else minOf(w, h)
        setMeasuredDimension(s, s)
    }

    private fun withAlpha(color: Int, a: Int): Int =
        Color.argb(a.coerceIn(0, 255), Color.red(color), Color.green(color), Color.blue(color))

    override fun onDraw(canvas: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val base = minOf(width, height) / 2f
        val twoPi = (2.0 * PI).toFloat()
        val breathe = (sin(t * twoPi) + 1f) / 2f

        val accent = if (listening) pink else cyan
        val accent2 = if (listening) violet else blue

        // soft outer glow
        val glowR = base * (0.86f + 0.14f * breathe)
        glowPaint.shader = RadialGradient(
            cx, cy, glowR,
            intArrayOf(withAlpha(accent, 120), withAlpha(accent, 0)),
            floatArrayOf(0.3f, 1f),
            Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, glowR, glowPaint)

        // expanding rings
        ringPaint.strokeWidth = base * 0.012f + 1.5f
        val strength = if (listening) 1f else 0.35f
        for (i in 0..2) {
            val p = (t * 0.6f + i / 3f) % 1f
            val r = base * (0.42f + 0.52f * p)
            ringPaint.color = withAlpha(accent, ((1f - p) * 170f * strength).toInt())
            canvas.drawCircle(cx, cy, r, ringPaint)
        }

        // glossy core
        val coreR = base * (0.38f + 0.025f * breathe)
        corePaint.shader = RadialGradient(
            cx - coreR * 0.35f, cy - coreR * 0.4f, coreR * 1.5f,
            intArrayOf(Color.WHITE, accent, accent2),
            floatArrayOf(0f, 0.5f, 1f),
            Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, coreR, corePaint)

        // microphone icon
        val s = coreR / 2.2f
        rect.set(cx - s * 0.55f, cy - s * 1.15f, cx + s * 0.55f, cy + s * 0.3f)
        canvas.drawRoundRect(rect, s * 0.55f, s * 0.55f, iconFill)
        iconStroke.strokeWidth = s * 0.2f
        rect.set(cx - s * 0.95f, cy - s * 0.6f, cx + s * 0.95f, cy + s * 0.8f)
        canvas.drawArc(rect, 0f, 180f, false, iconStroke)
        canvas.drawLine(cx, cy + s * 0.8f, cx, cy + s * 1.15f, iconStroke)
        canvas.drawLine(cx - s * 0.45f, cy + s * 1.15f, cx + s * 0.45f, cy + s * 1.15f, iconStroke)
    }
}
