package com.friday.assistant

// Persian consonants -> a rough Latin consonant class. Vowels (ا و ی ع ...) are dropped on purpose,
// because Persian script usually leaves short vowels out anyway.
private val faConsonants: Map<Char, Char> = mapOf(
    'ب' to 'b', 'پ' to 'p', 'ت' to 't', 'ط' to 't', 'ث' to 's', 'س' to 's', 'ص' to 's',
    'ج' to 'j', 'چ' to 'c', 'ح' to 'h', 'ه' to 'h', 'ة' to 'h', 'خ' to 'x', 'د' to 'd',
    'ذ' to 'z', 'ز' to 'z', 'ض' to 'z', 'ظ' to 'z', 'ژ' to 'z', 'ر' to 'r', 'ش' to 'S',
    'غ' to 'q', 'ق' to 'q', 'ف' to 'f', 'ک' to 'k', 'ك' to 'k', 'گ' to 'g', 'ل' to 'l',
    'م' to 'm', 'ن' to 'n'
)

/** Consonant skeleton of a Persian name: "علی رضایی" -> "lrz". */
fun skeletonFa(s: String): String {
    val sb = StringBuilder()
    for (ch in s) {
        val m = faConsonants[ch] ?: continue
        if (sb.isEmpty() || sb[sb.length - 1] != m) sb.append(m)
    }
    return sb.toString()
}

/** Consonant skeleton of a Latin name: "Ali Rezaei" -> "lrz". */
fun skeletonLatin(s: String): String {
    val t = s.lowercase()
        .replace("kh", "x").replace("sh", "S").replace("ch", "c")
        .replace("gh", "q").replace("zh", "z").replace("ph", "f").replace("th", "t")
    val sb = StringBuilder()
    for (ch in t) {
        val m = when (ch) {
            'b', 'p', 't', 'j', 'c', 'd', 'r', 'f', 'k', 'g', 'l', 'm', 'n', 'h', 'q', 'x', 'S' -> ch
            's' -> 's'
            'z' -> 'z'
            else -> continue
        }
        if (sb.isEmpty() || sb[sb.length - 1] != m) sb.append(m)
    }
    return sb.toString()
}
