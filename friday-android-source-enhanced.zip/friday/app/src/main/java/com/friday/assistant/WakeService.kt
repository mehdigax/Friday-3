package com.friday.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import java.util.Locale

/**
 * Experimental hands-free mode: keeps the speech recognizer listening and reacts when it hears
 * "فرایدی" / "Friday". Whatever is said after the wake word is passed to Friday as the command.
 */
class WakeService : Service() {

    companion object {
        const val ACTION_PAUSE = "com.friday.assistant.WAKE_PAUSE"
        const val ACTION_STOP = "com.friday.assistant.WAKE_STOP"
        const val EXTRA_LANG = "lang"

        private const val CH_WAKE = "friday_wake"
        private const val CH_ALERT = "friday_alert"
        private const val ID_WAKE = 21
        private const val ID_ALERT = 22

        @Volatile
        var running = false
    }

    private val handler = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var langTag = "fa-IR"
    private var failures = 0
    private var paused = false
    private var wakeLock: PowerManager.WakeLock? = null

    private val wakeWords = setOf("فرایدی", "فرایدای", "friday", "بیدارشو")

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action
        if (action == ACTION_STOP) {
            setWakePref(false)
            stopSelf()
            return START_NOT_STICKY
        }
        if (action == ACTION_PAUSE) {
            if (!running) {
                stopSelf()
            } else {
                pauseFor(15000L)
            }
            return START_NOT_STICKY
        }

        langTag = intent?.getStringExtra(EXTRA_LANG) ?: langTag
        try {
            startForegroundCompat()
        } catch (e: Exception) {
            running = false
            stopSelf()
            return START_NOT_STICKY
        }
        running = true
        failures = 0
        acquireWakeLock()
        resume()
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        running = false
        handler.removeCallbacksAndMessages(null)
        recognizer?.destroy()
        recognizer = null
        stopForeground(true)
        releaseWakeLock()
        super.onDestroy()
    }

    // ------------------------------------------------------------- notifications

    private fun ensureChannels() {
        if (Build.VERSION.SDK_INT < 26) return
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CH_WAKE, "بیدارباش فرایدی", NotificationManager.IMPORTANCE_LOW)
        )
        nm.createNotificationChannel(
            NotificationChannel(CH_ALERT, "هشدار فرایدی", NotificationManager.IMPORTANCE_HIGH)
        )
    }

    private fun newBuilder(channel: String): Notification.Builder =
        if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(this, channel)
        } else {
            Notification.Builder(this)
        }

    /** Opens Friday; with a command it runs it, without one it just starts listening. */
    private fun openPending(command: String?, requestCode: Int): PendingIntent {
        val i = Intent(this, MainActivity::class.java)
        if (command.isNullOrEmpty()) {
            i.putExtra(MainActivity.EXTRA_LISTEN, true)
        } else {
            i.putExtra(MainActivity.EXTRA_COMMAND, command)
        }
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        i.putExtra(MainActivity.EXTRA_FROM_WAKE, true)
        return PendingIntent.getActivity(
            this, requestCode, i,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun buildOngoing(): Notification {
        ensureChannels()
        val b = newBuilder(CH_WAKE)
        b.setSmallIcon(R.drawable.ic_mic)
        b.setContentTitle("Friday")
        b.setContentText("منتظر «فرایدی» یا «بیدار شو» هستم...")
        b.setContentIntent(openPending(null, 30))
        b.setOngoing(true)
        b.setShowWhen(false)
        if (Build.VERSION.SDK_INT < 26) b.setPriority(Notification.PRIORITY_LOW)

        val stop = Intent(this, WakeService::class.java)
        stop.action = ACTION_STOP
        val stopPending = PendingIntent.getService(
            this, 31, stop, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        b.addAction(R.drawable.ic_mic, "خاموش کردن", stopPending)
        return b.build()
    }

    private fun startForegroundCompat() {
        val n = buildOngoing()
        if (Build.VERSION.SDK_INT >= 30) {
            startForeground(ID_WAKE, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(ID_WAKE, n)
        }
    }

    /** A heads-up notification (used when Android blocks opening the app from the background). */
    private fun alert(title: String, text: String, command: String?) {
        ensureChannels()
        val b = newBuilder(CH_ALERT)
        b.setSmallIcon(R.drawable.ic_mic)
        b.setContentTitle(title)
        b.setContentText(text)
        b.setAutoCancel(true)
        b.setContentIntent(openPending(command, 32))
        // wakes the screen and shows Friday over the lock screen (if Android allows it)
        b.setFullScreenIntent(openPending(command, 33), true)
        if (Build.VERSION.SDK_INT < 26) b.setPriority(Notification.PRIORITY_HIGH)
        getSystemService(NotificationManager::class.java).notify(ID_ALERT, b.build())
    }

    // ------------------------------------------------------------- listening loop

    private fun normalize(s: String): String =
        s.lowercase(Locale.ROOT)
            .replace('\u064A', '\u06CC')
            .replace('\u0649', '\u06CC')
            .replace('\u0643', '\u06A9')
            .replace('\u0622', '\u0627')
            .replace("\u200c", "")
            .replace(Regex("[^\\p{L}\\p{N}]"), "")

    private fun setWakePref(on: Boolean) {
        getSharedPreferences("friday_settings", MODE_PRIVATE).edit().putBoolean("wake_on", on).apply()
    }

    /** Keeps the CPU running while the screen is off so listening doesn't freeze. */
    private fun acquireWakeLock() {
        try {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            val wl: PowerManager.WakeLock = wakeLock
                ?: pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "friday:wake")
            wl.setReferenceCounted(false)
            wakeLock = wl
            wl.acquire(2 * 60 * 60 * 1000L)
        } catch (e: Exception) {
            // ignore
        }
    }

    private fun releaseWakeLock() {
        try {
            wakeLock?.release()
        } catch (e: Exception) {
            // ignore
        }
        wakeLock = null
    }

    private fun pauseFor(ms: Long) {
        paused = true
        handler.removeCallbacksAndMessages(null)
        recognizer?.destroy()
        recognizer = null
        handler.postDelayed({ resume() }, ms)
    }

    private fun resume() {
        paused = false
        handler.removeCallbacksAndMessages(null)
        handler.post { listenOnce() }
    }

    private fun giveUp() {
        setWakePref(false)
        alert("فرایدی", "بیدارباش متوقف شد (سرویس تشخیص گفتار در دسترس نبود).", null)
        stopSelf()
    }

    private fun listenOnce() {
        if (paused || !running) return
        acquireWakeLock()
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            giveUp()
            return
        }
        recognizer?.destroy()
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}

            override fun onError(error: Int) {
                if (paused || !running) return
                if (error == SpeechRecognizer.ERROR_NO_MATCH ||
                    error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT
                ) {
                    // silence is normal: just listen again
                    failures = 0
                    handler.postDelayed({ listenOnce() }, 250L)
                } else if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
                    giveUp()
                } else {
                    failures++
                    if (failures >= 8) {
                        giveUp()
                    } else {
                        handler.postDelayed({ listenOnce() }, 1000L * failures)
                    }
                }
            }

            override fun onResults(results: Bundle?) {
                if (paused || !running) return
                failures = 0
                val text = results
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull()
                val cmd = if (text.isNullOrBlank()) null else extractCommand(text)
                if (cmd == null) {
                    handler.postDelayed({ listenOnce() }, 250L)
                } else {
                    trigger(cmd)
                }
            }
        })

        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        i.putExtra(
            RecognizerIntent.EXTRA_LANGUAGE_MODEL,
            RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
        )
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, langTag)
        i.putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
        r.startListening(i)
    }

    /** Returns null if the wake word wasn't said, otherwise whatever came after it (may be empty). */
    private fun extractCommand(text: String): String? {
        val raw = text.trim().split(Regex("\\s+"))
        val n = raw.map { normalize(it) }
        for (i in n.indices) {
            var len = 0
            if (n[i] in wakeWords) {
                len = 1
            } else if (i + 1 < n.size && (n[i] + n[i + 1]) in wakeWords) {
                len = 2
            }
            if (len > 0) {
                return raw.drop(i + len).joinToString(" ").trim()
            }
        }
        return null
    }

    /** Wake word heard: release the mic, bring Friday to the front, resume listening later. */
    private fun trigger(cmd: String) {
        paused = true
        handler.removeCallbacksAndMessages(null)
        recognizer?.destroy()
        recognizer = null

        val intent = Intent(this, MainActivity::class.java)
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        intent.putExtra(MainActivity.EXTRA_FROM_WAKE, true)
        if (cmd.isEmpty()) {
            intent.putExtra(MainActivity.EXTRA_LISTEN, true)
        } else {
            intent.putExtra(MainActivity.EXTRA_COMMAND, cmd)
        }
        try {
            startActivity(intent)
        } catch (e: Exception) {
            // the fallback below takes care of it
        }

        // If Android blocked the background launch, show a heads-up notification instead.
        handler.postDelayed({
            if (!MainActivity.visible) {
                alert(
                    "فرایدی صدات رو شنید",
                    if (cmd.isEmpty()) "برای شروع حرف زدن بزن" else "«$cmd» — برای اجرا بزن",
                    cmd
                )
            }
        }, 1500L)
        handler.postDelayed({ resume() }, 20000L)
    }
}
