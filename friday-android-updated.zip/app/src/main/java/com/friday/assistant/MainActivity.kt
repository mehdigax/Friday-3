package com.friday.assistant

import android.Manifest
import android.app.Activity
import android.content.Context
import android.media.AudioManager
import android.view.KeyEvent
import android.provider.CalendarContract
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.AlarmClock
import android.provider.ContactsContract.CommonDataKinds.Phone
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.text.InputType
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

data class AppInfo(val label: String, val pkg: String, val nLabel: String)
data class ContactInfo(val name: String, val number: String, val nName: String)

/** Normalizes Persian/Arabic variants, removes spaces, ZWNJ and punctuation. */
private fun norm(s: String): String =
    s.lowercase(Locale.ROOT)
        .replace('\u064A', '\u06CC') // ي -> ی
        .replace('\u0649', '\u06CC') // ى -> ی
        .replace('\u0643', '\u06A9') // ك -> ک
        .replace('\u0622', '\u0627') // آ -> ا
        .replace("\u200c", "")
        .replace(Regex("[^\\p{L}\\p{N}]"), "")

private fun String.faDigits(): String =
    map { if (it in '0'..'9') '\u06F0' + (it - '0') else it }.joinToString("")

/** Keeps only digits and a leading +, converting Persian/Arabic digits to Latin. */
private fun cleanNumber(s: String): String =
    s.filter { it.isDigit() || it == '+' }
        .map { if (it == '+') "+" else it.digitToInt().toString() }
        .joinToString("")

private val faOnes = listOf(
    "صفر", "یک", "دو", "سه", "چهار", "پنج", "شش", "هفت", "هشت", "نه", "ده",
    "یازده", "دوازده", "سیزده", "چهارده", "پانزده", "شانزده", "هفده", "هجده", "نوزده"
)
private val faTens = listOf(
    "", "", "بیست", "سی", "چهل", "پنجاه", "شصت", "هفتاد", "هشتاد", "نود"
)
private val faHundreds = listOf(
    "", "صد", "دویست", "سیصد", "چهارصد", "پانصد", "ششصد", "هفتصد", "هشتصد", "نهصد"
)

/** 1405 -> "هزار و چهارصد و پنج" (so robotic voices don't have to guess how to read digits). */
private fun faWords(n: Int): String {
    if (n == 0) return faOnes[0]
    val parts = ArrayList<String>()
    var x = n
    val thousands = x / 1000
    x %= 1000
    if (thousands > 0) {
        parts.add(if (thousands == 1) "هزار" else faWords(thousands) + " هزار")
    }
    val h = x / 100
    x %= 100
    if (h > 0) parts.add(faHundreds[h])
    if (x > 0) {
        if (x < 20) {
            parts.add(faOnes[x])
        } else {
            val t = x / 10
            val o = x % 10
            parts.add(if (o == 0) faTens[t] else faTens[t] + " و " + faOnes[o])
        }
    }
    return parts.joinToString(" و ")
}

/** Replaces digits with Persian words for speech: short numbers as a number, long ones digit by digit. */
private fun spokenFa(s: String): String =
    Regex("[0-9\\u06F0-\\u06F9]+").replace(s) { m ->
        val digits = m.value.map { it.digitToInt() }
        if (digits.size <= 4) {
            faWords(digits.joinToString("").toInt())
        } else {
            digits.joinToString(" ") { faOnes[it] }
        }
    }

private val smsWords = setOf("پیامک", "پیام", "sms", "message", "text")
private val sendVerbs = setOf(
    "بفرست", "بفرستید", "بفرستم", "بده", "بنویس", "بزن", "send", "write"
)
private val smsStopWords = setOf(
    "به", "برای", "با", "یه", "یک", "پیامک", "پیام", "sms", "message", "text",
    "لطفا", "فرایدی", "friday", "هی", "to", "a", "the", "من", "که"
)

private val faNumberWords = mapOf(
    "یک" to 1, "دو" to 2, "سه" to 3, "چهار" to 4, "پنج" to 5, "شش" to 6, "هفت" to 7,
    "هشت" to 8, "نه" to 9, "ده" to 10, "یازده" to 11, "دوازده" to 12, "سیزده" to 13,
    "چهارده" to 14, "پانزده" to 15, "شانزده" to 16, "هفده" to 17, "هجده" to 18,
    "نوزده" to 19, "بیست" to 20, "سی" to 30, "چهل" to 40, "پنجاه" to 50, "شصت" to 60
)

/** Converts Persian/Arabic digits to Latin ones. */
private fun toAscii(s: String): String =
    s.map { if (it.isDigit()) it.digitToInt().toString() else it.toString() }.joinToString("")

/** "7" -> 7, "هفت" -> 7 */
private fun numberToken(t: String?): Int? {
    if (t == null) return null
    val n = norm(t)
    val asInt = n.toIntOrNull()
    if (asInt != null) return asInt
    return faNumberWords[n]
}

private fun finishClock(h0: Int, m: Int, ascii: String): Pair<Int, Int>? {
    val s = norm(ascii)
    var h = h0
    val evening = s.contains("عصر") || s.contains("شب") || s.contains("بعدازظهر")
    if (evening && h in 1..11) {
        h += 12
    } else if (s.contains("ظهر") && h in 1..4) {
        h += 12
    }
    if (s.contains("شب") && h0 == 12) {
        h = 0
    }
    if (h > 23 || m > 59) return null
    return Pair(h, m)
}

/** Understands "ساعت ۷", "ساعت هفت و نیم", "۶:۴۵", "ساعت ۸ شب" ... */
private fun parseClock(raw: String): Pair<Int, Int>? {
    val ascii = toAscii(raw)
    val colon = Regex("(\\d{1,2})\\s*[:.\\u066B]\\s*(\\d{2})").find(ascii)
    if (colon != null) {
        return finishClock(colon.groupValues[1].toInt(), colon.groupValues[2].toInt(), ascii)
    }
    val tokens = ascii.split(Regex("\\s+")).filter { it.isNotEmpty() }
    val i = tokens.indexOfFirst { norm(it) == "ساعت" }
    if (i < 0) return null
    val h = numberToken(tokens.getOrNull(i + 1)) ?: return null
    val rest = tokens.drop(i + 2).map { norm(it) }
    var m = 0
    if (rest.firstOrNull() == "و") {
        val w = rest.getOrNull(1)
        m = when {
            w == "نیم" -> 30
            w == "ربع" -> 15
            else -> numberToken(w) ?: 0
        }
    }
    return finishClock(h, m, ascii)
}

/** Understands "۵ دقیقه", "نیم ساعت", "۱ ساعت و ۳۰ دقیقه", "۱۰ ثانیه" ... */
private fun parseDurationSeconds(raw: String): Int {
    val tokens = toAscii(raw).split(Regex("\\s+")).map { norm(it) }.filter { it.isNotEmpty() }
    var total = 0
    for (i in tokens.indices) {
        val unit = tokens.getOrNull(i + 1) ?: continue
        val mult = when (unit) {
            "ساعت", "hour", "hours" -> 3600
            "دقیقه", "minute", "minutes", "min" -> 60
            "ثانیه", "second", "seconds", "sec" -> 1
            else -> 0
        }
        if (mult == 0) continue
        val t = tokens[i]
        if (t == "نیم") {
            total += mult / 2
        } else if (t == "ربع") {
            total += mult / 4
        } else {
            val n = numberToken(t)
            if (n != null) total += n * mult
        }
    }
    if (total == 0 && tokens.contains("ربع")) total = 900
    return total
}

private fun describeDuration(total: Int): String {
    val h = total / 3600
    val m = (total % 3600) / 60
    val s = total % 60
    val parts = ArrayList<String>()
    if (h > 0) parts.add("$h ساعت")
    if (m > 0) parts.add("$m دقیقه")
    if (s > 0) parts.add("$s ثانیه")
    return parts.joinToString(" و ")
}

/** Gregorian -> Jalali (Persian) date. Returns (year, month, day). */
private fun gregorianToJalali(gy0: Int, gm: Int, gd: Int): Triple<Int, Int, Int> {
    val gdm = intArrayOf(0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334)
    var jy: Int
    var gy = gy0
    if (gy > 1600) {
        jy = 979
        gy -= 1600
    } else {
        jy = 0
        gy -= 621
    }
    val gy2 = if (gm > 2) gy + 1 else gy
    var days = (365 * gy) + ((gy2 + 3) / 4) - ((gy2 + 99) / 100) + ((gy2 + 399) / 400) -
        80 + gd + gdm[gm - 1]
    jy += 33 * (days / 12053)
    days %= 12053
    jy += 4 * (days / 1461)
    days %= 1461
    if (days > 365) {
        jy += (days - 1) / 365
        days = (days - 1) % 365
    }
    val jm: Int
    val jd: Int
    if (days < 186) {
        jm = 1 + days / 31
        jd = 1 + days % 31
    } else {
        jm = 7 + (days - 186) / 30
        jd = 1 + (days - 186) % 30
    }
    return Triple(jy, jm, jd)
}

class MainActivity : Activity() {

    private lateinit var orb: OrbView
    private lateinit var statusView: TextView
    private lateinit var heardView: TextView
    private lateinit var cancelButton: TextView
    private lateinit var langPill: TextView
    private lateinit var inputView: EditText
    private lateinit var wakePill: TextView

    private val handler = Handler(Looper.getMainLooper())
    private var pendingCall: Runnable? = null

    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var langTag = "fa-IR"
    private var autoListen = false
    private var torchOn = false

    companion object {
        /** Set by the home-screen widget: start listening as soon as the app opens. */
        const val EXTRA_LISTEN = "friday_listen"

        /** Set by the wake-word service: run this sentence as a command right away. */
        const val EXTRA_COMMAND = "friday_command"

        /** True while Friday's screen is in front (used by the wake-word fallback). */
        @Volatile
        var visible = false
    }

    private val MP = ViewGroup.LayoutParams.MATCH_PARENT
    private val WC = ViewGroup.LayoutParams.WRAP_CONTENT

    private val faWeekdays = listOf(
        "یکشنبه", "دوشنبه", "سه‌شنبه", "چهارشنبه", "پنجشنبه", "جمعه", "شنبه"
    )
    private val faMonths = listOf(
        "فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور",
        "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند"
    )

    private val openWords = setOf(
        "باز", "بازکن", "بازکنید", "اجرا", "اجراکن", "open", "launch", "start"
    )
    private val stopWords = openWords + setOf(
        "کن", "لطفا", "برنامه", "برنامهی", "اپلیکیشن", "نرمافزار", "رو", "را",
        "به", "برو", "فرایدی", "friday", "هی", "the", "app"
    )

    private val callWords = setOf("زنگ", "تماس", "call", "dial")
    private val callStopWords = callWords + setOf(
        "بزن", "بزنید", "بگیر", "بگیرید", "به", "با", "رو", "را", "کن", "لطفا",
        "فرایدی", "friday", "هی", "to", "please", "شماره", "برای", "من"
    )

    // Persian spoken name -> keywords to look for in app label / package name
    private val aliases: List<Pair<String, List<String>>> = listOf(
        "واتساپ" to listOf("whatsapp"),
        "واتسپ" to listOf("whatsapp"),
        "تلگرام" to listOf("telegram"),
        "اینستاگرام" to listOf("instagram"),
        "اینستا" to listOf("instagram"),
        "یوتیوب" to listOf("youtube"),
        "کروم" to listOf("chrome"),
        "گوگلمپ" to listOf("com.google.android.apps.maps"),
        "نقشه" to listOf("com.google.android.apps.maps", "maps"),
        "گوگل" to listOf("com.google.android.googlequicksearchbox"),
        "دوربین" to listOf("camera"),
        "تنظیمات" to listOf("com.android.settings", "settings"),
        "گالری" to listOf("gallery", "photos"),
        "ماشینحساب" to listOf("calculator"),
        "ساعت" to listOf("clock"),
        "تقویم" to listOf("calendar"),
        "مخاطبین" to listOf("contacts"),
        "تماس" to listOf("dialer", "phone"),
        "پیامک" to listOf("messag", "mms"),
        "ایتا" to listOf("eitaa"),
        "روبیکا" to listOf("rubika"),
        "اسنپ" to listOf("snapp"),
        "دیجیکالا" to listOf("digikala"),
        "بازار" to listOf("bazaar"),
        "مایکت" to listOf("myket"),
        "موزیک" to listOf("music"),
        "فایل" to listOf("files"),
        "پلیاستور" to listOf("com.android.vending")
    ).map { norm(it.first) to it.second }
        .sortedByDescending { it.first.length }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        tts = TextToSpeech(this) { status -> ttsReady = (status == TextToSpeech.SUCCESS) }
        requestAllPerms()
        handleLaunchIntent(intent)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        if (intent != null) {
            setIntent(intent)
            handleLaunchIntent(intent)
        }
    }

    /** When opened from the widget, start listening right away (no extra tap needed). */
    private fun handleLaunchIntent(i: Intent?) {
        if (i == null) return
        val cmd = i.getStringExtra(EXTRA_COMMAND)
        if (cmd != null) {
            i.removeExtra(EXTRA_COMMAND)
            handler.postDelayed({ handle(cmd) }, 1000L)
            return
        }
        if (!i.getBooleanExtra(EXTRA_LISTEN, false)) return
        i.removeExtra(EXTRA_LISTEN)
        if (hasPerm(Manifest.permission.RECORD_AUDIO)) {
            handler.postDelayed({ startListening() }, 350L)
        } else {
            autoListen = true // start once the mic permission is granted
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (!hasPerm(Manifest.permission.RECORD_AUDIO)) {
            autoListen = false
            setStatus("بدون اجازه‌ی میکروفون نمی‌تونم صدات رو بشنوم.")
        } else if (autoListen) {
            autoListen = false
            handler.postDelayed({ startListening() }, 350L)
        }
    }

    override fun onResume() {
        super.onResume()
        visible = true
        updateWakePill()
    }

    override fun onPause() {
        visible = false
        super.onPause()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        recognizer?.destroy()
        tts?.shutdown()
        super.onDestroy()
    }

    // ---------------------------------------------------------------- Permissions

    private fun hasPerm(p: String): Boolean =
        checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    private fun requestAllPerms() {
        val need = arrayOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.CALL_PHONE
        ).filter { !hasPerm(it) }
        if (need.isNotEmpty()) {
            requestPermissions(need.toTypedArray(), 1)
        }
    }

    // ---------------------------------------------------------------- UI

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun shape(
        fill: Int,
        radiusDp: Int,
        strokeColor: Int = 0,
        strokeDp: Int = 0
    ): GradientDrawable {
        val g = GradientDrawable()
        g.shape = GradientDrawable.RECTANGLE
        g.cornerRadius = dp(radiusDp).toFloat()
        g.setColor(fill)
        if (strokeDp > 0) {
            g.setStroke(dp(strokeDp), strokeColor)
        }
        return g
    }

    private fun buildUi() {
        window.statusBarColor = Color.parseColor("#070B1A")
        window.navigationBarColor = Color.parseColor("#1A1040")

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.background = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(
                Color.parseColor("#070B1A"),
                Color.parseColor("#0E1530"),
                Color.parseColor("#1A1040")
            )
        )
        root.setPadding(dp(20), dp(12), dp(20), dp(20))

        // ---- top bar: title + language pill
        val topBar = LinearLayout(this)
        topBar.orientation = LinearLayout.HORIZONTAL
        topBar.gravity = Gravity.CENTER_VERTICAL

        val titleBox = LinearLayout(this)
        titleBox.orientation = LinearLayout.VERTICAL

        val title = TextView(this)
        title.text = "FRIDAY"
        title.textSize = 24f
        title.letterSpacing = 0.3f
        title.typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
        title.setTextColor(Color.parseColor("#E8F6FF"))

        val subtitle = TextView(this)
        subtitle.text = "VOICE ASSISTANT"
        subtitle.textSize = 10.5f
        subtitle.letterSpacing = 0.25f
        subtitle.setTextColor(Color.parseColor("#29D8FF"))

        titleBox.addView(title)
        titleBox.addView(subtitle)

        langPill = TextView(this)
        langPill.text = "🌐 فارسی"
        langPill.textSize = 13f
        langPill.setTextColor(Color.parseColor("#C9D1E7"))
        langPill.setPadding(dp(14), dp(8), dp(14), dp(8))
        langPill.background = shape(
            Color.parseColor("#14FFFFFF"), 20, Color.parseColor("#33FFFFFF"), 1
        )
        langPill.setOnClickListener { toggleLang() }

        wakePill = TextView(this)
        wakePill.textSize = 13f
        wakePill.setPadding(dp(12), dp(8), dp(12), dp(8))
        wakePill.setOnClickListener { toggleWake() }
        updateWakePill()

        topBar.addView(titleBox, LinearLayout.LayoutParams(0, WC, 1f))
        val wakeParams = LinearLayout.LayoutParams(WC, WC)
        wakeParams.rightMargin = dp(8)
        topBar.addView(wakePill, wakeParams)
        topBar.addView(langPill)

        // ---- orb (tap to talk)
        val orbBox = FrameLayout(this)
        orb = OrbView(this)
        orb.setOnClickListener { onOrbClick() }
        orbBox.addView(orb, FrameLayout.LayoutParams(MP, MP, Gravity.CENTER))

        // ---- cancel-call pill (only visible while a call is pending)
        cancelButton = TextView(this)
        cancelButton.text = "✋  لغو تماس"
        cancelButton.textSize = 17f
        cancelButton.setTextColor(Color.WHITE)
        cancelButton.typeface = Typeface.DEFAULT_BOLD
        cancelButton.gravity = Gravity.CENTER
        cancelButton.setPadding(dp(20), dp(12), dp(20), dp(12))
        cancelButton.background = shape(Color.parseColor("#E63950"), 28)
        cancelButton.visibility = View.GONE
        cancelButton.setOnClickListener {
            cancelPending()
            setStatus("تماس لغو شد.")
        }

        // ---- glass card with status + what was heard
        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.gravity = Gravity.CENTER
        card.minimumHeight = dp(130)
        card.setPadding(dp(20), dp(18), dp(20), dp(18))
        card.background = shape(
            Color.parseColor("#14FFFFFF"), 26, Color.parseColor("#2629D8FF"), 1
        )

        statusView = TextView(this)
        statusView.text = "سلام! من فرایدی‌م 👋\nروی دایره بزن و حرف بزن،\nیا پایین تایپ کن."
        statusView.textSize = 19f
        statusView.setLineSpacing(0f, 1.15f)
        statusView.setTextColor(Color.parseColor("#F2F7FF"))
        statusView.gravity = Gravity.CENTER

        heardView = TextView(this)
        heardView.textSize = 14f
        heardView.setTextColor(Color.parseColor("#7F8BB0"))
        heardView.gravity = Gravity.CENTER
        heardView.setPadding(0, dp(8), 0, 0)
        heardView.visibility = View.GONE

        card.addView(statusView, LinearLayout.LayoutParams(MP, WC))
        card.addView(heardView, LinearLayout.LayoutParams(MP, WC))

        // ---- typed command bar
        val inputRow = LinearLayout(this)
        inputRow.orientation = LinearLayout.HORIZONTAL
        inputRow.gravity = Gravity.CENTER_VERTICAL

        inputView = EditText(this)
        inputView.background = shape(
            Color.parseColor("#14FFFFFF"), 26, Color.parseColor("#33FFFFFF"), 1
        )
        inputView.setPadding(dp(18), dp(12), dp(18), dp(12))
        inputView.hint = "یا دستورت رو تایپ کن..."
        inputView.setHintTextColor(Color.parseColor("#5E6A8F"))
        inputView.setTextColor(Color.parseColor("#F2F7FF"))
        inputView.textSize = 16f
        inputView.inputType = InputType.TYPE_CLASS_TEXT
        inputView.setSingleLine(true)
        inputView.imeOptions = EditorInfo.IME_ACTION_SEND
        inputView.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEND) {
                submitTyped()
                true
            } else {
                false
            }
        }

        val sendBtn = ImageView(this)
        sendBtn.setImageResource(R.drawable.ic_send)
        sendBtn.setPadding(dp(12), dp(12), dp(12), dp(12))
        val sendBg = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(Color.parseColor("#29D8FF"), Color.parseColor("#3A6BFF"))
        )
        sendBg.shape = GradientDrawable.OVAL
        sendBtn.background = sendBg
        sendBtn.setOnClickListener { submitTyped() }

        inputRow.addView(inputView, LinearLayout.LayoutParams(0, WC, 1f))
        val sendParams = LinearLayout.LayoutParams(dp(48), dp(48))
        sendParams.leftMargin = dp(10)
        inputRow.addView(sendBtn, sendParams)

        // ---- example hint
        val hint = TextView(this)
        hint.text = "«واتساپ رو باز کن»  •  «ساعت چنده؟»  •  «به علی زنگ بزن»\n«چراغ قوه روشن کن»  •  «آلارم ساعت ۷»  •  «تایمر ۵ دقیقه»"
        hint.textSize = 12.5f
        hint.setTextColor(Color.parseColor("#5E6A8F"))
        hint.gravity = Gravity.CENTER
        hint.setPadding(0, dp(14), 0, 0)

        root.addView(topBar, LinearLayout.LayoutParams(MP, WC))
        root.addView(orbBox, LinearLayout.LayoutParams(MP, 0, 1f))
        val cancelParams = LinearLayout.LayoutParams(MP, WC)
        cancelParams.bottomMargin = dp(12)
        root.addView(cancelButton, cancelParams)
        root.addView(card, LinearLayout.LayoutParams(MP, WC))
        val inputParams = LinearLayout.LayoutParams(MP, WC)
        inputParams.topMargin = dp(12)
        root.addView(inputRow, inputParams)
        root.addView(hint, LinearLayout.LayoutParams(MP, WC))

        setContentView(root)
    }

    private fun setStatus(text: String) {
        statusView.alpha = 0f
        statusView.text = text
        statusView.animate().alpha(1f).setDuration(220).start()
    }

    private fun setHeard(text: String) {
        if (text.isEmpty()) {
            heardView.visibility = View.GONE
        } else {
            heardView.text = text
            heardView.visibility = View.VISIBLE
        }
    }

    private fun onOrbClick() {
        hideKeyboard()
        orb.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
        orb.animate().scaleX(0.93f).scaleY(0.93f).setDuration(90).withEndAction {
            orb.animate().scaleX(1f).scaleY(1f).setDuration(140).start()
        }.start()
        startListening()
    }

    /** Runs a command that was typed instead of spoken. */
    private fun submitTyped() {
        val text = inputView.text.toString().trim()
        if (text.isEmpty()) return
        inputView.setText("")
        hideKeyboard()
        recognizer?.cancel()
        orb.listening = false
        tts?.stop()
        handle(text)
    }

    private fun hideKeyboard() {
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(inputView.windowToken, 0)
        inputView.clearFocus()
    }

    private fun toggleLang() {
        if (langTag == "fa-IR") {
            langTag = "en-US"
            langPill.text = "🌐 English"
        } else {
            langTag = "fa-IR"
            langPill.text = "🌐 فارسی"
        }
    }

    // ---------------------------------------------------------------- Listening

    private fun startListening() {
        if (WakeService.running) {
            val pause = Intent(this, WakeService::class.java)
            pause.action = WakeService.ACTION_PAUSE
            startService(pause)
            handler.postDelayed({ beginListening() }, 500L)
        } else {
            beginListening()
        }
    }

    private fun beginListening() {
        if (!hasPerm(Manifest.permission.RECORD_AUDIO)) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            setStatus("سرویس تشخیص گفتار گوگل روی این گوشی پیدا نشد.")
            return
        }
        recognizer?.destroy()
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}

            override fun onError(error: Int) {
                orb.listening = false
                setStatus("متوجه نشدم، دوباره روی دایره بزن. (کد $error)")
            }

            override fun onResults(results: Bundle?) {
                orb.listening = false
                val text = results
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull()
                if (text.isNullOrBlank()) {
                    setStatus("چیزی نشنیدم.")
                } else {
                    handle(text)
                }
            }
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        intent.putExtra(
            RecognizerIntent.EXTRA_LANGUAGE_MODEL,
            RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
        )
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, langTag)
        r.startListening(intent)

        orb.listening = true
        setHeard("")
        setStatus("دارم گوش می‌دم...")
    }

    // ---------------------------------------------------------------- Commands

    private fun handle(raw: String) {
        setHeard("«$raw»")
        cancelPending()
        val tokens = raw.split(Regex("\\s+")).map { norm(it) }.filter { it.isNotEmpty() }
        val full = tokens.joinToString("")

        // 0) flashlight / wifi / bluetooth / alarm / timer / sms
        if (handleDeviceCommands(raw, tokens, full)) return

        // 0.5) navigation, web search, media controls, volume and calendar
        if (handleExtraCommands(raw, tokens, full)) return

        // 1) open an app
        val wantsOpen = tokens.any { it in openWords } || full.contains("بازکن")
        if (wantsOpen) {
            val query = tokens.filter { it !in stopWords }.joinToString("")
            openApp(query, full)
            return
        }

        // 2) call someone
        val wantsCall = tokens.any { it in callWords } ||
            full.contains("زنگبزن") || full.contains("تماسبگیر")
        if (wantsCall) {
            handleCall(raw, tokens)
            return
        }

        // 3) time / date
        val wantTime = full.contains("ساعت") || full.contains("time") || full.contains("زمان")
        val wantDate = full.contains("تاریخ") || full.contains("امروز") ||
            full.contains("روز") || full.contains("date") || full.contains("today")

        if (wantTime || wantDate) {
            answerTimeDate(wantTime, wantDate)
        } else {
            reply(
                "متوجه نشدم. بگو «واتساپ رو باز کن»، «ساعت و تاریخ» یا «به علی زنگ بزن».",
                "Sorry, I didn't understand."
            )
        }
    }


    /** Navigation, browser search, media, volume and calendar intents. */
    private fun handleExtraCommands(raw: String, tokens: List<String>, full: String): Boolean {
        fun launch(i: Intent, message: String, english: String = message) {
            reply(message, english)
            handler.postDelayed({
                if (!startSafely(i)) reply("برنامه‌ای برای انجام این کار پیدا نشد.", "No compatible app found.")
            }, 500L)
        }

        // Navigation: "برو به ...", "مسیریابی به ..."
        val nav = full.contains("مسیریابی") || full.contains("مسیریاب") ||
            full.startsWith("بروبه") || full.startsWith("منوببر") ||
            full.startsWith("navigate") || full.startsWith("directions")
        if (nav) {
            var destination = raw
            listOf("مسیریابی", "مسیریاب", "برو به", "بروبه", "منو ببر به", "navigate to", "directions to")
                .forEach { destination = destination.replace(it, "", ignoreCase = true) }
            destination = destination.trim().trim('،', '.', ' ')
            if (destination.isBlank()) {
                reply("مقصد رو بگو؛ مثلاً «مسیریابی به میدان آزادی».", "Tell me a destination.")
            } else {
                val uri = Uri.parse("google.navigation:q=" + Uri.encode(destination))
                launch(Intent(Intent.ACTION_VIEW, uri).setPackage("com.google.android.apps.maps"),
                    "مسیریابی به $destination رو باز می‌کنم.", "Opening navigation to $destination.")
            }
            return true
        }

        // Web search
        if (full.contains("جستجو") || full.contains("سرچ") || full.contains("search") ||
            full.contains("توی اینترنت") || full.contains("در اینترنت")) {
            var q = raw
            listOf("توی اینترنت", "در اینترنت", "جستجو کن", "جستجو", "سرچ کن", "سرچ", "search for", "search")
                .forEach { q = q.replace(it, "", ignoreCase = true) }
            q = q.trim().trim('،', ' ')
            if (q.isBlank()) {
                launch(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com")), "جستجوی اینترنت رو باز می‌کنم.")
            } else {
                launch(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(q))),
                    "نتایج جستجوی «$q» رو باز می‌کنم.", "Searching the web for $q.")
            }
            return true
        }

        // Volume: Android controls the actual stream; user can also use hardware keys.
        if (full.contains("صدا") || full.contains("بلندی") || full.contains("volume")) {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            when {
                full.contains("بیصدا") || full.contains("ساکت") || full.contains("mute") ->
                    am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, 0)
                full.contains("زیاد") || full.contains("بلندتر") || full.contains("up") ->
                    am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
                full.contains("کم") || full.contains("پایین") || full.contains("down") ->
                    am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
                full.contains("با صدا") || full.contains("unmute") ->
                    am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_UNMUTE, AudioManager.FLAG_SHOW_UI)
                else -> {
                    reply("بگو صدا رو زیاد، کم یا بی‌صدا کنم.", "Say volume up, volume down, or mute.")
                    return true
                }
            }
            reply("بلندی صدای رسانه تغییر کرد.", "Media volume changed.")
            return true
        }

        // Media controls through Android media-button broadcasts.
        if (full.contains("موسیقی") || full.contains("موزیک") || full.contains("آهنگ") ||
            full.contains("پخش") || full.contains("pause") || full.contains("play") ||
            full.contains("بعدی") || full.contains("قبلی") || full.contains("next track") ||
            full.contains("previous track")) {
            val key = when {
                full.contains("بعدی") || full.contains("next") -> KeyEvent.KEYCODE_MEDIA_NEXT
                full.contains("قبلی") || full.contains("previous") -> KeyEvent.KEYCODE_MEDIA_PREVIOUS
                full.contains("توقف") || full.contains("قطع") || full.contains("pause") || full.contains("متوقف") ->
                    KeyEvent.KEYCODE_MEDIA_PAUSE
                else -> KeyEvent.KEYCODE_MEDIA_PLAY
            }
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val down = Intent(Intent.ACTION_MEDIA_BUTTON).putExtra(Intent.EXTRA_KEY_EVENT, KeyEvent(KeyEvent.ACTION_DOWN, key))
            val up = Intent(Intent.ACTION_MEDIA_BUTTON).putExtra(Intent.EXTRA_KEY_EVENT, KeyEvent(KeyEvent.ACTION_UP, key))
            try {
                am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, key))
                am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, key))
                reply("فرمان کنترل موسیقی ارسال شد.", "Media control sent.")
            } catch (_: Exception) {
                reply("کنترل موسیقی در این دستگاه در دسترس نیست.", "Media controls aren't available.")
            }
            return true
        }

        // Calendar event: opens the system calendar editor so the user confirms/saves it.
        if (full.contains("تقویم") || full.contains("رویداد") || full.contains("قرار") ||
            full.contains("calendar") || full.contains("event")) {
            if (full.contains("یادآور") || full.contains("یادم") || full.contains("remind")) {
                val i = Intent(AlarmClock.ACTION_SET_ALARM)
                val clock = parseClock(raw)
                if (clock != null) {
                    i.putExtra(AlarmClock.EXTRA_HOUR, clock.first)
                    i.putExtra(AlarmClock.EXTRA_MINUTES, clock.second)
                    i.putExtra(AlarmClock.EXTRA_MESSAGE, raw)
                    launch(i, "صفحه‌ی تنظیم یادآور/آلارم رو باز می‌کنم؛ لطفاً تأییدش کن.")
                } else {
                    launch(Intent(Intent.ACTION_INSERT).setData(CalendarContract.Events.CONTENT_URI)
                        .putExtra(CalendarContract.Events.TITLE, raw),
                        "رویداد رو در تقویم باز می‌کنم تا زمانش رو مشخص و ذخیره کنی.")
                }
            } else {
                val title = raw.replace(Regex("(?i)ایجاد کن|اضافه کن|ثبت کن|بساز|رویداد|قرار|تقویم|calendar|event"), "").trim()
                val i = Intent(Intent.ACTION_INSERT).setData(CalendarContract.Events.CONTENT_URI)
                    .putExtra(CalendarContract.Events.TITLE, title.ifBlank { "رویداد جدید" })
                    .putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, System.currentTimeMillis() + 3600000L)
                    .putExtra(CalendarContract.EXTRA_EVENT_END_TIME, System.currentTimeMillis() + 7200000L)
                launch(i, "فرم رویداد تقویم باز می‌شه؛ تاریخ و ساعت رو بررسی و ذخیره کن.")
            }
            return true
        }
        return false
    }

    // ---------------------------------------------------------------- Wake mode (experimental)

    private fun updateWakePill() {
        val on = WakeService.running
        wakePill.text = if (on) "👂 روشن" else "👂 خاموش"
        wakePill.setTextColor(Color.parseColor(if (on) "#29D8FF" else "#C9D1E7"))
        wakePill.background = shape(
            Color.parseColor("#14FFFFFF"), 20,
            Color.parseColor(if (on) "#8029D8FF" else "#33FFFFFF"), 1
        )
    }

    private fun toggleWake() {
        if (WakeService.running) {
            stopService(Intent(this, WakeService::class.java))
            handler.postDelayed({ updateWakePill() }, 400L)
            setStatus("حالت بیدار شدن با «فرایدی» خاموش شد.")
            return
        }
        if (!hasPerm(Manifest.permission.RECORD_AUDIO)) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
            setStatus("اول اجازه‌ی میکروفون رو بده، بعد دوباره بزن.")
            return
        }
        if (Build.VERSION.SDK_INT >= 33 && !hasPerm(Manifest.permission.POST_NOTIFICATIONS)) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 3)
            setStatus("اجازه‌ی نوتیفیکیشن رو بده، بعد دوباره بزن.")
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            setStatus(
                "برای اینکه فرایدی بعد از شنیدن اسمش خودش باز بشه، اجازه‌ی «نمایش روی برنامه‌های دیگر» رو روشن کن، بعد برگرد و دوباره بزن."
            )
            startSafely(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
            return
        }
        val serviceIntent = Intent(this, WakeService::class.java)
        serviceIntent.putExtra(WakeService.EXTRA_LANG, langTag)
        if (Build.VERSION.SDK_INT >= 26) {
            startForegroundService(serviceIntent)
        } else {
            startService(serviceIntent)
        }
        handler.postDelayed({ updateWakePill() }, 600L)
        setStatus("حالت بیدار شدن روشن شد (آزمایشی). بگو «فرایدی، ساعت چنده؟»")
    }

    // ---------------------------------------------------------------- Device commands

    private fun startSafely(intent: Intent): Boolean =
        try {
            startActivity(intent)
            true
        } catch (e: Exception) {
            false
        }

    private fun setTorch(on: Boolean): Boolean {
        try {
            val cm = getSystemService(Context.CAMERA_SERVICE) as CameraManager
            var flashId: String? = null
            for (id in cm.cameraIdList) {
                val c = cm.getCameraCharacteristics(id)
                val hasFlash = c.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
                val back = c.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
                if (hasFlash && back) {
                    flashId = id
                    break
                }
            }
            if (flashId == null) return false
            cm.setTorchMode(flashId, on)
            torchOn = on
            return true
        } catch (e: Exception) {
            return false
        }
    }

    /** Returns true when the sentence was one of these commands. */
    private fun handleDeviceCommands(raw: String, tokens: List<String>, full: String): Boolean {
        // flashlight
        if (full.contains("چراغقوه") || full.contains("فلش") ||
            full.contains("flashlight") || full.contains("torch")
        ) {
            val off = full.contains("خاموش") || tokens.contains("off")
            val on = full.contains("روشن") || tokens.contains("on")
            val target = if (off) false else if (on) true else !torchOn
            if (setTorch(target)) {
                reply(
                    if (target) "چراغ‌قوه روشن شد" else "چراغ‌قوه خاموش شد",
                    if (target) "Flashlight on" else "Flashlight off"
                )
            } else {
                if (!hasPerm(Manifest.permission.CAMERA)) {
                    requestPermissions(arrayOf(Manifest.permission.CAMERA), 5)
                    reply(
                        "اگه چراغ قوه روشن نشد، اجازه‌ی دوربین رو بده و دوباره بگو.",
                        "Please allow camera access for the flashlight, then try again."
                    )
                } else {
                    reply("چراغ قوه روی این گوشی در دسترس نیست.", "The flashlight isn't available.")
                }
            }
            return true
        }

        // wifi (Android doesn't let apps switch it directly -> open the panel)
        if (full.contains("وایفای") || full.contains("wifi")) {
            val i = if (Build.VERSION.SDK_INT >= 30) {
                Intent(Settings.Panel.ACTION_WIFI)
            } else {
                Intent(Settings.ACTION_WIFI_SETTINGS)
            }
            reply(
                "پنل وای‌فای رو باز می‌کنم. اندروید اجازه نمی‌ده برنامه‌ها مستقیم روشن یا خاموشش کنن؛ خودت بزنش.",
                "Opening Wi-Fi settings."
            )
            handler.postDelayed({ startSafely(i) }, 800L)
            return true
        }

        // bluetooth
        if (full.contains("بلوتوث") || full.contains("bluetooth")) {
            reply(
                "تنظیمات بلوتوث رو باز می‌کنم. اندروید اجازه نمی‌ده برنامه‌ها مستقیم تغییرش بدن؛ خودت بزنش.",
                "Opening Bluetooth settings."
            )
            handler.postDelayed({ startSafely(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)) }, 800L)
            return true
        }

        // alarm
        if (full.contains("الارم") || full.contains("هشدار") || full.contains("بیدارم") ||
            full.contains("alarm") || full.contains("زنگساعت")
        ) {
            val clock = parseClock(raw)
            if (clock == null) {
                reply(
                    "ساعت آلارم رو متوجه نشدم. مثلاً بگو «آلارم برای ساعت هفت و نیم».",
                    "I didn't catch the alarm time."
                )
                return true
            }
            val h = clock.first
            val m = clock.second
            val i = Intent(AlarmClock.ACTION_SET_ALARM)
            i.putExtra(AlarmClock.EXTRA_HOUR, h)
            i.putExtra(AlarmClock.EXTRA_MINUTES, m)
            i.putExtra(AlarmClock.EXTRA_MESSAGE, "Friday")
            i.putExtra(AlarmClock.EXTRA_SKIP_UI, true)
            val said = if (m == 0) "ساعت $h" else "ساعت $h و $m دقیقه"
            reply("آلارم برای $said تنظیم شد", "Alarm set for $h:" + m.toString().padStart(2, '0'))
            handler.postDelayed({
                if (!startSafely(i)) {
                    reply("برنامه‌ی ساعت برای تنظیم آلارم پیدا نشد.", "No clock app found.")
                }
            }, 600L)
            return true
        }

        // timer
        if (full.contains("تایمر") || full.contains("timer") ||
            full.contains("زمانسنج") || full.contains("زمانشمار")
        ) {
            val secs = parseDurationSeconds(raw)
            if (secs <= 0) {
                reply(
                    "مدت تایمر رو متوجه نشدم. مثلاً بگو «تایمر ۵ دقیقه».",
                    "I didn't catch the timer length."
                )
                return true
            }
            val i = Intent(AlarmClock.ACTION_SET_TIMER)
            i.putExtra(AlarmClock.EXTRA_LENGTH, secs)
            i.putExtra(AlarmClock.EXTRA_MESSAGE, "Friday")
            i.putExtra(AlarmClock.EXTRA_SKIP_UI, true)
            reply("تایمر " + describeDuration(secs) + " تنظیم شد", "Timer set")
            handler.postDelayed({
                if (!startSafely(i)) {
                    reply("برنامه‌ی ساعت برای تنظیم تایمر پیدا نشد.", "No clock app found.")
                }
            }, 600L)
            return true
        }

        // sms
        if (tokens.any { it in smsWords } && tokens.any { it in sendVerbs }) {
            handleSms(raw)
            return true
        }
        return false
    }

    private fun handleSms(raw: String) {
        val words = raw.split(Regex("\\s+")).filter { it.isNotEmpty() }
        val vi = words.indexOfFirst { norm(it) in sendVerbs }
        val head = if (vi >= 0) words.take(vi) else words
        var bodyWords = if (vi >= 0) words.drop(vi + 1) else emptyList()
        if (bodyWords.isNotEmpty() && norm(bodyWords[0]) == "که") {
            bodyWords = bodyWords.drop(1)
        }
        val body = bodyWords.joinToString(" ")

        val headDigits = toAscii(head.joinToString(" ")).filter { it.isDigit() }
        val number: String
        val who: String
        if (headDigits.length >= 7) {
            number = headDigits
            who = headDigits
        } else {
            val query = head.map { norm(it) }
                .filter { it.isNotEmpty() && it !in smsStopWords }
                .joinToString("")
            if (query.isEmpty()) {
                reply("برای کی پیامک بفرستم؟", "Who should I text?")
                return
            }
            if (!hasPerm(Manifest.permission.READ_CONTACTS)) {
                requestPermissions(arrayOf(Manifest.permission.READ_CONTACTS), 2)
                reply(
                    "برای پیدا کردن مخاطب، اجازه‌ی خوندن مخاطبین رو بده و دوباره بگو.",
                    "I need permission to read your contacts."
                )
                return
            }
            val matches = findContacts(query)
            val names = matches.map { it.name }.distinct()
            if (matches.isEmpty()) {
                reply("مخاطبی به اسم «$query» پیدا نکردم.", "I couldn't find that contact.")
                return
            }
            if (names.size > 1) {
                reply(
                    "چند نفر پیدا شد: " + names.take(5).joinToString("، ") + ". اسم کامل‌تر رو بگو.",
                    "I found several matches. Please say the full name."
                )
                return
            }
            val c = pickNumber(matches)
            number = c.number
            who = c.name
        }

        val intent = Intent(Intent.ACTION_SENDTO, Uri.fromParts("smsto", number, null))
        if (body.isNotEmpty()) {
            intent.putExtra("sms_body", body)
        }
        reply(
            "پیامک برای $who آماده شد. دکمه‌ی ارسال رو خودت بزن.",
            "The message is ready. Tap send."
        )
        handler.postDelayed({
            if (!startSafely(intent)) {
                reply("برنامه‌ی پیامک پیدا نشد.", "No messaging app found.")
            }
        }, 800L)
    }

    // ---------------------------------------------------------------- Open apps

    private fun loadApps(): List<AppInfo> {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return packageManager.queryIntentActivities(intent, 0)
            .map {
                val label = it.loadLabel(packageManager).toString()
                AppInfo(label, it.activityInfo.packageName, norm(label))
            }
            .filter { it.pkg != packageName }
    }

    private fun findApp(query: String, full: String): AppInfo? {
        val apps = loadApps()
        val nq = norm(query)

        // 1) exact label match
        if (nq.isNotEmpty()) {
            apps.firstOrNull { it.nLabel == nq }?.let { return it }
        }
        // 2) Persian aliases (واتساپ -> whatsapp, ...)
        for ((fa, keys) in aliases) {
            if (full.contains(fa)) {
                for (k in keys) {
                    apps.firstOrNull {
                        it.nLabel.contains(k) || it.pkg.lowercase(Locale.ROOT).contains(k)
                    }?.let { return it }
                }
            }
        }
        // 3) partial label match
        if (nq.length >= 2) {
            apps.filter {
                it.nLabel.length >= 2 && (nq.contains(it.nLabel) || it.nLabel.contains(nq))
            }.minByOrNull { it.nLabel.length }?.let { return it }
        }
        return null
    }

    private fun openApp(query: String, full: String) {
        if (query.isEmpty()) {
            reply("کدوم برنامه رو باز کنم؟", "Which app should I open?")
            return
        }
        val app = findApp(query, full)
        val launch = app?.let { packageManager.getLaunchIntentForPackage(it.pkg) }
        if (app == null || launch == null) {
            reply("برنامه‌ای به اسم «$query» پیدا نکردم.", "I couldn't find that app.")
            return
        }
        reply("دارم ${app.label} رو باز می‌کنم", "Opening ${app.label}")
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        handler.postDelayed({ startActivity(launch) }, 800)
    }

    // ---------------------------------------------------------------- Calls

    private fun loadContacts(): List<ContactInfo> {
        val list = ArrayList<ContactInfo>()
        val cursor = contentResolver.query(
            Phone.CONTENT_URI,
            arrayOf(Phone.DISPLAY_NAME, Phone.NUMBER),
            null, null, null
        ) ?: return list
        cursor.use {
            val ni = it.getColumnIndex(Phone.DISPLAY_NAME)
            val pi = it.getColumnIndex(Phone.NUMBER)
            while (it.moveToNext()) {
                val name = it.getString(ni) ?: continue
                val num = it.getString(pi) ?: continue
                val clean = cleanNumber(num)
                if (clean.isNotEmpty()) {
                    list.add(ContactInfo(name, clean, norm(name)))
                }
            }
        }
        return list
    }

    private fun findContacts(query: String): List<ContactInfo> {
        val nq = norm(query)
        if (nq.isEmpty()) return emptyList()
        val all = loadContacts()

        val exact = all.filter { it.nName == nq }
        if (exact.isNotEmpty()) return exact

        if (nq.length >= 2) {
            val partial = all.filter { it.nName.contains(nq) }
            if (partial.isNotEmpty()) return partial
        }
        return all.filter { it.nName.length >= 2 && nq.contains(it.nName) }
    }

    /** Prefers a mobile number when the same person has several numbers. */
    private fun pickNumber(list: List<ContactInfo>): ContactInfo =
        list.firstOrNull {
            it.number.startsWith("09") || it.number.startsWith("+989") ||
                it.number.startsWith("00989")
        } ?: list.first()

    private fun handleCall(raw: String, tokens: List<String>) {
        // a) a spoken / dictated phone number
        val digits = raw.filter { it.isDigit() }
            .map { it.digitToInt().toString() }
            .joinToString("")
        if (digits.length >= 7) {
            reply("دارم با شماره‌ی $digits تماس می‌گیرم", "Calling $digits")
            scheduleCall(digits)
            return
        }

        // b) a contact name
        val query = tokens.filter { it !in callStopWords }.joinToString("")
        if (query.isEmpty()) {
            reply("به کی زنگ بزنم؟", "Who should I call?")
            return
        }
        if (!hasPerm(Manifest.permission.READ_CONTACTS)) {
            requestPermissions(arrayOf(Manifest.permission.READ_CONTACTS), 2)
            reply(
                "برای پیدا کردن مخاطب، اجازه‌ی خوندن مخاطبین رو بده و دوباره بگو.",
                "I need permission to read your contacts."
            )
            return
        }

        val matches = findContacts(query)
        val names = matches.map { it.name }.distinct()
        when {
            matches.isEmpty() ->
                reply("مخاطبی به اسم «$query» پیدا نکردم.", "I couldn't find that contact.")

            names.size > 1 ->
                reply(
                    "چند نفر پیدا شد: " + names.take(5).joinToString("، ") +
                        ". اسم کامل‌تر رو بگو.",
                    "I found several matches. Please say the full name."
                )

            else -> {
                val c = pickNumber(matches)
                reply("دارم به ${c.name} زنگ می‌زنم", "Calling ${c.name}")
                scheduleCall(c.number)
            }
        }
    }

    private fun cancelLabel(left: Int): String =
        "✋  لغو تماس (" + left.toString().faDigits() + ")"

    /** Counts down 3 seconds so a wrong recognition can be cancelled, then places the call. */
    private fun scheduleCall(number: String) {
        cancelPending()
        val canCall = hasPerm(Manifest.permission.CALL_PHONE)
        val action = if (canCall) Intent.ACTION_CALL else Intent.ACTION_DIAL
        val intent = Intent(action, Uri.fromParts("tel", number, null))
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

        var left = 3
        cancelButton.text = cancelLabel(left)
        cancelButton.visibility = View.VISIBLE
        if (!canCall) {
            statusView.text = statusView.text.toString() +
                "\n\n(اجازه‌ی تماس مستقیم داده نشده؛ صفحه‌ی شماره‌گیر باز می‌شه)"
        }

        val r = object : Runnable {
            override fun run() {
                left--
                if (left > 0) {
                    cancelButton.text = cancelLabel(left)
                    handler.postDelayed(this, 1000L)
                } else {
                    pendingCall = null
                    cancelButton.visibility = View.GONE
                    startActivity(intent)
                }
            }
        }
        pendingCall = r
        handler.postDelayed(r, 1000L)
    }

    private fun cancelPending() {
        pendingCall?.let { handler.removeCallbacks(it) }
        pendingCall = null
        cancelButton.visibility = View.GONE
    }

    // ---------------------------------------------------------------- Time & date

    private fun answerTimeDate(wantTime: Boolean, wantDate: Boolean) {
        val cal = Calendar.getInstance()
        val h = cal.get(Calendar.HOUR_OF_DAY)
        val min = cal.get(Calendar.MINUTE)

        val weekday = faWeekdays[cal.get(Calendar.DAY_OF_WEEK) - 1]
        val (year, jm, day) = gregorianToJalali(
            cal.get(Calendar.YEAR),
            cal.get(Calendar.MONTH) + 1,
            cal.get(Calendar.DAY_OF_MONTH)
        )
        val month = faMonths[jm - 1]

        val faTime = if (min == 0) "ساعت $h است" else "ساعت $h و $min دقیقه است"
        val faDate = "امروز $weekday $day $month $year است"

        val now = Date()
        val enTime = "It is " + SimpleDateFormat("h:mm a", Locale.US).format(now)
        val enDate = "Today is " + SimpleDateFormat("EEEE, MMMM d, yyyy", Locale.US).format(now)

        val fa = listOfNotNull(
            if (wantTime) faTime else null,
            if (wantDate) faDate else null
        ).joinToString(". ")
        val en = listOfNotNull(
            if (wantTime) enTime else null,
            if (wantDate) enDate else null
        ).joinToString(". ")

        reply(fa, en)
    }

    // ---------------------------------------------------------------- Speaking

    /** Shows [fa] on screen and speaks it (Persian voice if available, else English [en]). */
    private fun reply(fa: String, en: String) {
        val spokeFa = speak(fa, en)
        setStatus(
            fa.faDigits() +
                if (spokeFa) "" else "\n\n(صدای فارسی روی این گوشی نصب نیست؛ انگلیسی می‌گم)"
        )
    }

    private fun speak(fa: String, en: String): Boolean {
        val engine = tts ?: return false
        if (!ttsReady) return false
        val faOk = engine.isLanguageAvailable(Locale("fa")) >= TextToSpeech.LANG_AVAILABLE
        return if (faOk) {
            engine.setLanguage(Locale("fa"))
            engine.setPitch(1.0f)
            engine.setSpeechRate(0.85f) // a bit slower = clearer on robotic voices
            engine.speak(spokenFa(fa), TextToSpeech.QUEUE_FLUSH, null, "friday")
            true
        } else {
            engine.setLanguage(Locale.US)
            engine.setSpeechRate(1.0f)
            engine.speak(en, TextToSpeech.QUEUE_FLUSH, null, "friday")
            false
        }
    }
}
